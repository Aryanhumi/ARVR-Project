# Publish this folder

## GitHub Desktop (easy option)

1. Choose File > Add Local Repository and select this folder. If asked, create a repository here.
2. Review Changes. `Assets`, `Packages`, `ProjectSettings`, documentation and tests should appear. `Library`, builds and personal signing keys should not.
3. Commit with a message such as `Add Surface Racer Unity project`.
4. Choose Publish repository, set the repository name and visibility, and publish.

## Terminal option

Run these commands in this folder, not its parent:

```powershell
git init
git add .
git status
git commit -m "Add Surface Racer Unity project"
git branch -M main
```

Create an empty GitHub repository, then use its actual URL:

```powershell
git remote add origin https://github.com/YOUR-USERNAME/AR-Car-Racing.git
git push -u origin main
```

The URL is a placeholder; replace it before running. This folder is not connected to a remote yet.

## Keep future changes together

After confirming this copy opens correctly, use this folder as your project in Unity Hub. Changes made in the old RaceAR folder will not automatically appear here. Commit changed `.meta` files together with their assets. Unity regenerates `Library`, IDE project files and local preferences.

Keep APKs as optional GitHub Release downloads rather than source commits. Keep signing passwords and keys outside the repository. Review publishing permissions for any third-party assets before making the project public.
