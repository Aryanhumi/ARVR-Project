# Surface Racer — current setup

The Unity project is the repository root (this folder).
This update replaces the old always-visible button toolbar with a three-dot options menu.

## Build and run
1. Stop Unity Play mode and allow scripts/shaders to import.
2. For laptop practice choose AR Racing > Testing > Desktop Driving, then Play.
3. For the phone choose AR Racing > Build And Run Android (Standalone), with the authorized Android phone connected. Rebuild replaces the installed app; the old APK does not contain these changes.
4. Once installed, the phone game runs without USB.

## Three modes
- Free Drive: explore the selected surface and collect coins/checkpoint portals. Depth blocking starts OFF. End the run from the three-dot menu to see results.
- Track Race: 3, 5 or 10 ordered laps, 16 checkpoints per lap, boost pickups, timer and saved best time for each layout/size bucket. Depth blocking starts OFF for a less frustrating race.
- Obstacle Run: a 60-second score challenge with experimental room-depth blocking ON. Coin/portal scoring continues. The sensor needs supported ARCore depth hardware and current camera coverage.

Obstacle mode uses geometric depth, not semantic recognition of chairs, slippers or human legs. Thin, low, moving, out-of-view or poorly reconstructed objects may be missed. Turning on this mode does not make unsupported phones acquire depth.

## Scan, preview, place, start
Choose a mode. Move the phone slowly across textured patches/corners in good light. TARGET filters AUTO, FLOOR, WALL or CEILING. A small indicator marks a valid placement surface. Tap the actual room surface to hold a preview there; tap another spot to change it.

Track Race shows a translucent road preview. Choose Grand Prix Sprint, Chicane Challenge or Technical GP; use SIZE - / + to scale between 0.75x and 4x, and ROTATE to turn by 15 degrees. Preview center follows the selected location; the car starts at the circuit's start mark, away from its center. Size changes apply before placement and include road width, checkpoint and pickup layout.

Press PLACE TRACK (or PLACE CAR), then START. The place button stays disabled until a usable surface pose is available. The preview can extend beyond the native detected patch; it does not certify that the complete real floor area is free of obstacles. Plain featureless walls still need texture/corners, lighting and camera motion for reliable AR tracking.

Track mode attaches the road, checkpoints and pickups to one AR anchor. Racing does not reposition/resize that root or automatically turn it onto a different wall. Native AR tracking can still refine its estimated anchor pose; no software can guarantee zero drift. Free and Obstacle modes retain the earlier experimental adjoining-surface traversal.

## Minimal driving screen
Left/right and up/down arrow pads work by holding or swiping; multiple fingers work together. Steering and acceleration now ease smoothly. BOOST drives forward independently while held; BRAKE takes priority. FORCE GO drives forward while bypassing depth collision stops only while held, and still respects brake, reverse, pause, focus loss and tracking loss.

PAUSE stops immediately. START / RESUME resumes on the existing track without reloading it or resetting progress/time. Opening the three-dot menu also stops driving; CLOSE returns to the same run. Lost tracking pauses movement and race timing until stable tracking recovers.

The three-dot menu contains recover, reposition, scan more, reset map, target filter, manual wall estimate, coins, scan lines, collision overrides, sound, vibration, finish run and main menu. Reposition intentionally ends the current run and returns to placement. RESET MAP also clears native room mapping and no-block spots.

Track pickups produce a brief translucent flash and replenish nitro. Room coins also give pickup feedback. Sound and vibration are optional, start OFF and remember the selection. Vibration duration/strength depend on the phone.

## Racing and results
Pass the highlighted checkpoint in the arrow direction. Every ordered circuit completes a lap; the selected final lap opens results with Race Again and Main Menu. Leaving the road beyond the edge tolerance for 0.2 seconds starts a 1.25-second fall/burst effect, then returns only the car to the previous checkpoint. The ghost and race timer continue; the track stays anchored.

Race Again resets score/time/laps/pickups on the same placed circuit and waits for START. Main Menu returns to mode selection. FINISH RUN can end a session early, but an incomplete track race does not update best time. This is a solo race against a scripted ghost pace rival with a saved personal best. The ghost is not a recorded player run or a network opponent.

## Optional object blocking
The driving plane itself is excluded from depth collisions, with a 5.5cm normal-distance noise tolerance. Native plane boundaries are not colliders or limits on free driving.

NO BLOCK HIT ignores a 35cm-radius sphere around the last red depth contact, if pressed within eight seconds. Large objects can need more than one spot. RESTORE HIT removes the latest exception. CLEAR IGNORES removes all. BLOCKING OFF disables depth blocking globally.

These are fixed room-coordinate spots, not tracked object identities; they do not follow a moving chair or person. At most 16 spots are retained. Map reset/app restart clears them.

## Verification and remaining device checks
Runtime and Editor C# compile against the installed Unity 6000.6 / AR Foundation 6.6.2 references. 191 logic checks pass for controls, smoother motion, pause/focus state, surface geometry, collision filtering/exclusions, track geometry, size limits, checkpoint ordering, lap completion and progress reset.

The new UI, custom transparent shader, audio/haptics, Android rendering, physical tracking and on-device race flow have not been play-tested from this environment. No new APK was built here. On the phone verify preview selection/rotation/size, placement lock while walking, three-lap completion, pause/resume, Race Again, menu return, pickup flash and optional sound/vibration.

The source archive includes Assets/ARRacing, the entry scene and this guide. The complete project remains in RaceAR; Unity maintains Library automatically.

## Interface correction
The HUD now selects one screen at a time: Main, Placement, Ready/Resume, Racing, Options, Manual Calibration or Results. Inactive screens are closed at initialization, before label updates and immediately after navigation. A modal touch shield prevents tapping controls underneath a dialog. Entering another screen releases held driving inputs.

The options panel and placement panel are larger; buttons have opaque backgrounds, borders, brighter press tint, a small caption press animation and legible disabled labels. Start and Resume have separate captions, and the placement TARGET button displays its active filter. Manual calibration cancellation returns to placement.

Rebuild and replace the installed APK. Validate on the phone: fresh launch shows only Main Menu; choose mode to see Placement only; place to see Start only; pause/resume; open/close Options; finish to see Results only; Race Again; Main Menu; manual calibration/cancel. No phone logs or play test were available here (ADB could not connect), so the 191 passing checks verify state/input logic and compilation, not Android visual rendering.

## Grand Prix update
Three original F1-inspired layouts replace the earlier oval variations:
- Grand Prix Sprint: fast straight, braking zone and infield corners.
- Chicane Challenge: direction changes and tighter technical sections.
- Technical GP: a longer sequence of hairpins and mixed corners.

Choose one of the three named buttons before placement. LAPS cycles 3, 5 and 10 (default 5). SIZE scales the full course from 0.75x to 4x; the preview displays its approximate footprint in metres. A larger course increases real driving distance and requires more physical viewing space. Keep the car visible and use a size suited to your room. Course roots remain locked after placement.

Red-and-white kerbs mark the road edges. After a short 0.2-second edge grace period, leaving the road triggers an arcade fall and expanding orange burst. Controls stop during the 1.25-second crash recovery, then the car respawns at its previous checkpoint. Race time and the ghost keep advancing during the crash. Pause, menus and lost tracking freeze both. The results include crash count.

A translucent blue, non-colliding ghost car appears only in Track mode. It races at a fixed 0.68m/s using distance along the curved course, so its pace does not surge between control points. The HUD shows P1/P2 and estimated gap in metres; results show whether you beat it. It stops at the finish after the selected lap count. Race Again resets both cars on the same anchored course.

Best times use new keys including layout, size and lap count; the old circular-course records are not compared with these GP times. Sound and vibration remain optional; the crash currently shares the enabled feedback cue with pickups.

191 checks cover the existing systems plus lap choices, off-road tolerance, segment distance, ghost path distance/wrapping, scaling and non-crossing circuit centre-lines. C# compiles against the installed project references. Device visuals, road width/turning feel, crash animation and ghost rendering still require a rebuilt APK and a phone play test.

## Placement spacing and optional chase view
Placement buttons now have gaps between all rows. The duplicate centre scan message and the detected-plane polygon behind an active track preview are hidden, reducing visual overlap. Placement shows a scanning-stage header instead of live race standings.

During racing, VIEW: AR / VIEW: CHASE toggles a separate third-person camera window. AR view is the default. The window shows the virtual car/course from behind the car, against a plain background; it does not synthesize a new perspective of the camera's real-room video. The device camera, tracked pose driver, depth sampling camera and course anchor are unchanged. Menus/pause hide the window. The secondary camera renders at 640x360 only when the window is visible; enabling it adds some GPU work.

Runtime/Editor compilation and the existing 191 logic checks pass. These checks do not exercise rendering or phone layout. Rebuild the APK, check placement row spacing, then start racing and try VIEW: CHASE. Return to VIEW: AR at any time if preferred.
