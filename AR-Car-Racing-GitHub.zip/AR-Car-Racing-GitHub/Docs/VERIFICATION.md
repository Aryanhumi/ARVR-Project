# Packaging verification

- Copied 842 files from the current working Unity project's Assets, Packages and ProjectSettings.
- Every copied file was SHA-256 compared with its source.
- Included scene: Assets/Scenes/ARRacing.unity; saved build settings enable that scene.
- Preserved Unity metadata and the dependency manifest/lock.
- Excluded generated Library, Logs, UserSettings, IDE files, APKs and previous development backups.
- No file in the source copy exceeds GitHub's 100 MiB individual-file limit.
- Original project was not moved or changed.
- Logic checks: all 191 existing checks passed when compiled and executed from this copied folder.
- Git repository initialized locally; no remote, commit or push was created. Git ignore rules verified for caches, APKs, test output and signing keys.
- Fresh Unity import, rendering and phone tracking were not rerun during packaging.
