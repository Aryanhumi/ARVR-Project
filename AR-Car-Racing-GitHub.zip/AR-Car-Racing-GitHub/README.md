# Surface Racer - AR Car Racing

A Unity mobile AR racing game with surface placement, touch driving, three Grand Prix-inspired circuits, a ghost competitor, Free Drive and an optional depth-based Obstacle Run.

## Open the game

1. Install **Unity 6000.6.0f1** through Unity Hub. Add Android Build Support, Android SDK/NDK Tools and OpenJDK for phone builds.
2. In Unity Hub choose **Add project from disk** and select this folder, which contains `Assets`, `Packages` and `ProjectSettings`.
3. Wait for package download and asset import. Unity creates `Library` automatically.
4. Open **Assets/Scenes/ARRacing.unity**. `SampleScene` is the original template tutorial, not the game.
5. Choose **AR Racing > Testing > Desktop Driving**, then press Play for laptop practice.

The copied build settings already select ARRacing. The editor setup script also attempts to open it after import when the active scene has no unsaved changes.

## Phone build

Switch the active build platform to Android. Connect an ARCore-compatible Android phone, enable USB debugging and authorize the computer. Choose **AR Racing > Build And Run Android (Standalone)**. Generated APKs go in `Builds/Android`. After installation, launch the app from its icon; USB is not required for normal play. Allow camera permission.

Real surface tracking requires a supported phone. Desktop Driving is gameplay practice; Simulated AR Scan uses a virtual environment and does not prove real room tracking with a laptop webcam.

## Play

- **Free Drive:** explore the selected surface and collect rewards.
- **Track Race:** choose Sprint, Chicane or Technical GP; adjust size, rotation and laps, preview, place, then start. Compete with a translucent scripted ghost. Leaving the road triggers a fall/burst and checkpoint recovery.
- **Obstacle Run:** a timed challenge with optional experimental geometric depth blocking. Depth support and camera coverage vary by phone; this is not semantic recognition of every room object.

Hold or swipe the left arrows to steer and the right arrows to drive forward/reverse. Boost can propel the car forward independently; brake takes priority. Pause and the three-dot options menu stop driving. Options include recovery, repositioning, scanning, collision overrides and optional sound/vibration. A separate chase-view window is available during racing.

## Folder guide

| Path | Contents |
| --- | --- |
| `Assets/ARRacing/Scripts` | Current game C# scripts |
| `Assets/ARRacing/Editor` | Scene configuration and build menu tools |
| `Assets/Scenes/ARRacing.unity` | Racing entry scene |
| `Assets/` | Full saved project assets and their Unity `.meta` files |
| `Packages/` | Package manifest and dependency lock |
| `ProjectSettings/` | Shared Unity, rendering, XR and Android configuration |
| `Docs/` | Detailed gameplay/setup notes and publishing instructions |
| `Tests~/` | Existing standalone C# logic checks; ignored by Unity import |

This is a verified source copy of the working Unity project. Generated caches, temporary files, local editor preferences, old backups and APK builds are excluded. Package versions and assets are preserved to avoid changing gameplay during organization. First import needs internet access to restore Unity packages.

## Put it on GitHub

See [Docs/GITHUB.md](Docs/GITHUB.md). Upload the contents of **this folder** as the repository root. Do not upload the parent work folder or an old source ZIP. No repository was published automatically.

## Verification and limitations

The source files were compared byte-for-byte against the original project during packaging. See [Docs/VERIFICATION.md](Docs/VERIFICATION.md) for the packaging checks and logic-check result. This copy still needs a normal Unity import and device smoke test after cloning; packaging is not a new phone rendering test.

Unity template/sample assets and package content keep their existing third-party notices. This package does not assign a new open-source license to those materials.
