using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using Unity.XR.CoreUtils;

namespace ARRacing.Editor
{
    public static class ARRaceSetup
    {
        [MenuItem("AR Racing/Testing/Desktop Driving")]
        static void DesktopMode()
        {
            EditorPrefs.SetBool("ARRacingSimulatedAR",false);
            EditorPrefs.SetInt("ARRacingPracticeSurface",0);
            Debug.Log("Desktop driving selected. Stop and restart Play to apply.");
        }
        [MenuItem("AR Racing/Testing/Desktop Wall Driving")]
        static void WallMode(){EditorPrefs.SetBool("ARRacingSimulatedAR",false);EditorPrefs.SetInt("ARRacingPracticeSurface",1);Debug.Log("Wall driving selected. Stop and restart Play.");}
        [MenuItem("AR Racing/Testing/Desktop Ceiling Driving")]
        static void CeilingMode(){EditorPrefs.SetBool("ARRacingSimulatedAR",false);EditorPrefs.SetInt("ARRacingPracticeSurface",2);Debug.Log("Ceiling driving selected. Stop and restart Play.");}
        [MenuItem("AR Racing/Testing/Simulated AR Scan")]
        static void SimulationMode()
        {
            EditorPrefs.SetBool("ARRacingSimulatedAR",true);
            Debug.Log("XR Simulation selected. Enable XR Simulation under XR Plug-in Management for the desktop Editor and choose a simulation environment. Stop and restart Play. This tests simulated planes, not the laptop webcam.");
        }
        [MenuItem("AR Racing/Build Windows Practice Version")]
        static void BuildWindows()
        {
            if(EditorApplication.isPlaying){Debug.LogError("Stop Play before building.");return;}
            Configure();System.IO.Directory.CreateDirectory("Builds/Windows");
            var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{
                scenes=new[]{"Assets/Scenes/ARRacing.unity"},locationPathName="Builds/Windows/RoomDrive.exe",
                target=BuildTarget.StandaloneWindows64,options=BuildOptions.None});
            Debug.Log("Windows practice build: "+report.summary.result+" - Builds/Windows/RoomDrive.exe");
        }
        [MenuItem("AR Racing/Build Android APK for Standalone Play")]
        static void BuildAndroidStandalone()
        { BuildAndroid(BuildOptions.None); }
        [MenuItem("AR Racing/Build And Run Android (Standalone)")]
        static void BuildAndRunAndroidStandalone()
        { BuildAndroid(BuildOptions.AutoRunPlayer); }
        static void BuildAndroid(BuildOptions options)
        {
            if(EditorApplication.isPlaying){Debug.LogError("Stop Play before building.");return;}
            Configure();
            EditorUserBuildSettings.development=false;
            EditorUserBuildSettings.connectProfiler=false;
            EditorUserBuildSettings.allowDebugging=false;
            EditorUserBuildSettings.waitForManagedDebugger=false;
            EditorUserBuildSettings.buildAppBundle=false;
            EditorUserBuildSettings.exportAsGoogleAndroidProject=false;
            System.IO.Directory.CreateDirectory("Builds/Android");
            var report=BuildPipeline.BuildPlayer(new BuildPlayerOptions{
                scenes=new[]{"Assets/Scenes/ARRacing.unity"},locationPathName="Builds/Android/RoomDrive.apk",
                target=BuildTarget.Android,options=options});
            Debug.Log("Standalone Android APK: "+report.summary.result+" - Builds/Android/RoomDrive.apk. Install on the phone; launch from the app icon without USB.");
        }
        [InitializeOnLoadMethod]
        static void OnImported()
        {
            if(SessionState.GetBool("ARRacingConfiguredRoomV2",false))return;
            EditorApplication.delayCall+=()=>
            {
                Configure();SessionState.SetBool("ARRacingConfiguredRoomV2",true);
                if(EditorApplication.isPlayingOrWillChangePlaymode)return;
                if(!EditorSceneManager.GetActiveScene().isDirty)
                    EditorSceneManager.OpenScene("Assets/Scenes/ARRacing.unity");
            };
        }
        [MenuItem("AR Racing/Create Racing Scene")]
        public static void CreateScene()
        {
            const string path="Assets/Scenes/ARRacing.unity";
            if(System.IO.File.Exists(path)){Configure();EditorSceneManager.OpenScene(path);Debug.Log("AR_RACING_SETUP_COMPLETE");return;}
            var scene=EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,NewSceneMode.Single);
            var session=new GameObject("AR Session",typeof(ARSession),typeof(ARInputManager));
            var originGO=new GameObject("XR Origin");
            var origin=originGO.AddComponent<XROrigin>();
            origin.CameraYOffset=0;
            var offset=new GameObject("Camera Offset");offset.transform.SetParent(originGO.transform,false);
            origin.CameraFloorOffsetObject=offset;
            var cameraGO=new GameObject("AR Camera");cameraGO.tag="MainCamera";cameraGO.transform.SetParent(offset.transform,false);
            var camera=cameraGO.AddComponent<Camera>();camera.nearClipPlane=.01f;camera.farClipPlane=30;
            cameraGO.AddComponent<AudioListener>();var cameraManager=cameraGO.AddComponent<ARCameraManager>();cameraManager.autoFocusRequested=true;cameraManager.requestedBackgroundRenderingMode=CameraBackgroundRenderingMode.BeforeOpaques;cameraGO.AddComponent<ARCameraBackground>();
            var tracking=cameraGO.AddComponent<TrackedPoseDriver>();
            ARRaceBootstrap.ConfigureTracking(tracking);
            origin.Camera=camera;
            var planes=originGO.AddComponent<ARPlaneManager>();planes.requestedDetectionMode=PlaneDetectionMode.Horizontal|PlaneDetectionMode.Vertical;
            var raycasts=originGO.AddComponent<ARRaycastManager>();originGO.AddComponent<ARAnchorManager>();
            var light=new GameObject("Sun").AddComponent<Light>();light.type=LightType.Directional;light.intensity=1.2f;light.transform.rotation=Quaternion.Euler(50,-30,0);
            RenderSettings.ambientLight=new Color(.6f,.65f,.7f);
            var game=new GameObject("Race Manager").AddComponent<ARRaceGame>();game.planes=planes;game.raycasts=raycasts;game.raceCamera=camera;
            EditorSceneManager.SaveScene(scene,path);
            Configure();
            AssetDatabase.SaveAssets();Debug.Log("AR_RACING_SETUP_COMPLETE");
        }
        static void Configure()
        {
            System.IO.Directory.CreateDirectory("Assets/ARRacing/Resources/ARRacing");
            foreach(var pair in new[]{new[]{"Scan","Universal Render Pipeline/Unlit"},new[]{"Surface","Universal Render Pipeline/Lit"}})
            {
                string assetPath="Assets/ARRacing/Resources/ARRacing/"+pair[0]+".mat";
                if(!AssetDatabase.LoadAssetAtPath<Material>(assetPath))
                    AssetDatabase.CreateAsset(new Material(Shader.Find(pair[1])),assetPath);
            }
            EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene("Assets/Scenes/ARRacing.unity",true)};
            PlayerSettings.companyName="Pocket Racing";PlayerSettings.productName="AR Car Racing";
            PlayerSettings.SetApplicationIdentifier(UnityEditor.Build.NamedBuildTarget.Android,"com.pocketracing.arracing");
            PlayerSettings.defaultInterfaceOrientation=UIOrientation.LandscapeLeft;
            PlayerSettings.Android.minSdkVersion=AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.SetScriptingBackend(UnityEditor.Build.NamedBuildTarget.Android,ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures=AndroidArchitecture.ARM64;
            AssetDatabase.SaveAssets();
        }
    }
}
