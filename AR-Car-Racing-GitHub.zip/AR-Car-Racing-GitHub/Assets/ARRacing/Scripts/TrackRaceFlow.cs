using UnityEngine;
namespace ARRacing
{
    // The circuit is created under the placement anchor once. No racing code moves it.
    public sealed class TrackMeshLifetime:MonoBehaviour {public Mesh ownedMesh;void OnDestroy(){if(ownedMesh)Destroy(ownedMesh);}}
    public sealed class TrackRaceFlow:MonoBehaviour
    {
        public ARRaceGame game;
        public RaceMode Mode {get;private set;}=RaceMode.Track;
        public RaceStage Stage {get;private set;}=RaceStage.Menu;
        public int TrackType {get;private set;}
        public float Size {get;private set;}=1;
        public float Heading {get;private set;}
        public float RaceTime {get;private set;}
        public bool Sound {get;private set;}
        public bool Vibration {get;private set;}
        public float Flash {get;private set;}
        public int RaceLaps {get;private set;}=5;public bool Crashing=>crashLeft>0;
        public bool AllowsDriving=>Stage==RaceStage.Racing&&!Crashing;
        public bool Locked=>Mode==RaceMode.Track&&game.HasCar;
        public string TrackName=>new[]{"Grand Prix Sprint","Chicane Challenge","Technical GP"}[TrackType];
        public string Progress=>Mode==RaceMode.Track?$"LAP {Mathf.Min(RaceLaps,progress.Laps+1)}/{RaceLaps}  /  GATE {progress.Next+1}/16  /  {RaceTime:0.0}s  /  {RivalText}":$"{Mode}  /  {RaceTime:0.0}s";
        string BestKey=>"ARRacing.GP2.Best."+TrackType+"."+Mathf.RoundToInt(Size*100)+"."+RaceLaps;
        public string BestText=>PlayerPrefs.HasKey(BestKey)?$"BEST {PlayerPrefs.GetFloat(BestKey):0.0}s":"Set your first best time";
        public string ResultsText=>Mode==RaceMode.Track?$"{(completed?RaceLaps+" LAPS COMPLETE":"RUN ENDED")}\n{RaceTime:0.0}s  /  {game.Score} points\n{BestText}\n{(completed?(RaceTime<=GhostFinishTime?"YOU BEAT THE GHOST":"GHOST WINS"):"")} / {crashes} crashes":$"{Mode} complete\n{RaceTime:0.0}s  /  {game.Score} points";
        readonly CircuitProgress progress=new CircuitProgress();
        Transform previewTrack,circuit,gate,ghost,blast;CircuitPace pace;Material ghostMaterial,crashMaterial;float ghostTravel,crashLeft,playerParameter;int crashes;
        const float GhostSpeed=.68f;
        float GhostFinishTime=>pace==null?float.PositiveInfinity:pace.Length*RaceLaps/GhostSpeed;
        string RivalText {
            get {
                if(Crashing)return "CRASH! RECOVERING";if(pace==null)return "GHOST READY";if(ghostTravel>=pace.Length*RaceLaps)return "GHOST FINISHED";
                int cleared=(progress.Next+15)%16;float t=Mathf.Clamp(playerParameter,cleared/16f,(cleared+1)/16f);
                float lead=progress.Laps*pace.Length+pace.DistanceAt(t)-ghostTravel;
                return (lead>=0?"P1 / GHOST -":"P2 / GHOST +")+Mathf.Abs(lead).ToString("0.0")+"m";
            }
        }
        readonly System.Collections.Generic.List<Transform> boosts=new System.Collections.Generic.List<Transform>();
        Material previewMaterial,roadMaterial,edgeMaterial,kerbRed,kerbWhite;
        int measuredType=-1;float measuredSize;string footprint;
        public string Footprint {get {if(measuredType!=TrackType||measuredSize!=Size){measuredType=TrackType;measuredSize=Size;float minX=999,minZ=999,maxX=-999,maxZ=-999;for(int i=0;i<256;i++){var p=Point(i/256f);minX=Mathf.Min(minX,p.x);maxX=Mathf.Max(maxX,p.x);minZ=Mathf.Min(minZ,p.z);maxZ=Mathf.Max(maxZ,p.z);}footprint=$"{maxX-minX+.7f*Size:0.0} x {maxZ-minZ+.7f*Size:0.0}m";}return footprint;}}
        AudioSource audioSource;AudioClip pickupSound;
        Vector3 previous;float outside;bool completed;
        void Awake(){
            game=GetComponent<ARRaceGame>();Sound=PlayerPrefs.GetInt("ARRacing.Sound",0)==1;Vibration=PlayerPrefs.GetInt("ARRacing.Vibration",0)==1;
            audioSource=gameObject.AddComponent<AudioSource>();audioSource.playOnAwake=false;audioSource.spatialBlend=0;
            var samples=new float[4800];for(int i=0;i<samples.Length;i++)samples[i]=Mathf.Sin(i*2*Mathf.PI*(660+440f*i/samples.Length)/24000)*.14f*(1f-i/(float)samples.Length);
            pickupSound=AudioClip.Create("Boost pickup",samples.Length,1,24000,false);pickupSound.SetData(samples,0);
            var shader=Resources.Load<Shader>("ARRacing/TrackPreview");
            previewMaterial=new Material(shader);previewMaterial.SetColor("_BaseColor",new Color(.1f,1,.8f,.20f));
            roadMaterial=new Material(shader);roadMaterial.SetColor("_BaseColor",new Color(.025f,.07f,.14f,.46f));
            edgeMaterial=new Material(Resources.Load<Material>("ARRacing/Scan"));edgeMaterial.color=new Color(.15f,1,.8f);
            ghostMaterial=new Material(shader);ghostMaterial.SetColor("_BaseColor",new Color(.2f,.75f,1,.32f));crashMaterial=new Material(shader);crashMaterial.SetColor("_BaseColor",new Color(1,.28f,.015f,.6f));
            kerbRed=new Material(edgeMaterial);kerbRed.color=new Color(1,.07f,.08f);kerbWhite=new Material(edgeMaterial);kerbWhite.color=Color.white;kerbRed.SetFloat("_Cull",0);kerbWhite.SetFloat("_Cull",0);
        }
        public void SelectMode(int mode){Mode=(RaceMode)mode;game.ShowScanForPlacement();game.Replace();Stage=RaceStage.Placement;game.SetObstacleBlocking(Mode==RaceMode.Obstacle);game.CloseScanMenu();}
        public void SetTrack(int type){if(Stage!=RaceStage.Placement||Mode!=RaceMode.Track)return;TrackType=Mathf.Clamp(type,0,2);RebuildPreview();}
        public void CycleLaps(){if(Stage==RaceStage.Placement)RaceLaps=RaceLaps==3?5:RaceLaps==5?10:3;}
        public void CycleTrack(){if(Stage!=RaceStage.Placement)return;TrackType=(TrackType+1)%3;RebuildPreview();}
        public void Resize(float delta){if(Stage!=RaceStage.Placement)return;Size=CircuitShape.Size(Size+delta);RebuildPreview();}
        public void RotatePreview(){if(Stage==RaceStage.Placement)Heading=(Heading+15)%360;}
        public Quaternion Rotation(Quaternion rotation)=>rotation*Quaternion.Euler(0,Heading,0);
        Vector3 Point(float t){CircuitShape.Point(TrackType,t,out float x,out float z);return new Vector3(x*Size,.008f,z*Size);}
        Vector3 Tangent(float t)=>(Point(t+.002f)-Point(t)).normalized;
        void RebuildPreview(){if(previewTrack)Destroy(previewTrack.gameObject);previewTrack=null;}
        public void Preview(Pose pose,bool valid){
            if(Mode!=RaceMode.Track||Stage!=RaceStage.Placement){if(previewTrack)previewTrack.gameObject.SetActive(false);return;}
            if(!previewTrack){previewTrack=new GameObject("Transparent circuit preview").transform;BuildRoad(previewTrack,true);DirectionMarks(previewTrack,true);}
            previewTrack.gameObject.SetActive(valid);previewTrack.SetPositionAndRotation(pose.position,Rotation(pose.rotation));
        }
        void BuildRoad(Transform parent,bool preview){
            const int count=256;var vertices=new Vector3[(count+1)*2];var triangles=new int[count*6];float halfWidth=.30f*Size;
            for(int i=0;i<=count;i++){float t=i/(float)count;Vector3 p=Point(t),side=Vector3.Cross(Vector3.up,Tangent(t));vertices[i*2]=p-side*halfWidth;vertices[i*2+1]=p+side*halfWidth;if(i<count){int v=i*2,k=i*6;triangles[k]=v;triangles[k+1]=v+2;triangles[k+2]=v+1;triangles[k+3]=v+1;triangles[k+4]=v+2;triangles[k+5]=v+3;}}
            var mesh=new Mesh();mesh.vertices=vertices;mesh.triangles=triangles;mesh.RecalculateNormals();var road=new GameObject("Translucent road",typeof(MeshFilter),typeof(MeshRenderer));road.transform.SetParent(parent,false);road.GetComponent<MeshFilter>().sharedMesh=mesh;road.AddComponent<TrackMeshLifetime>().ownedMesh=mesh;road.GetComponent<MeshRenderer>().sharedMaterial=preview?previewMaterial:roadMaterial;
            foreach(int side in new[]{-1,1}){var line=new GameObject("Road edge").AddComponent<LineRenderer>();line.transform.SetParent(parent,false);line.useWorldSpace=false;line.loop=true;line.positionCount=count;line.startWidth=line.endWidth=.009f;line.sharedMaterial=preview?previewMaterial:edgeMaterial;for(int i=0;i<count;i++){float t=i/(float)count;line.SetPosition(i,Point(t)+Vector3.Cross(Vector3.up,Tangent(t))*halfWidth*side+Vector3.up*.004f);}}
        }
        void DirectionMarks(Transform parent,bool preview){
            for(int i=0;i<16;i++){
                float t=i/16f;Vector3 centre=Point(t)+Vector3.up*.01f,forward=Tangent(t)*(.10f*Size),side=Vector3.Cross(Vector3.up,Tangent(t))*(.075f*Size);
                var arrow=new GameObject(i==0?"Start / finish":"Course direction").AddComponent<LineRenderer>();arrow.transform.SetParent(parent,false);arrow.useWorldSpace=false;arrow.positionCount=3;arrow.startWidth=arrow.endWidth=i==0?.028f:.012f;arrow.sharedMaterial=preview?previewMaterial:edgeMaterial;
                arrow.SetPosition(0,centre-forward-side);arrow.SetPosition(1,centre+forward);arrow.SetPosition(2,centre-forward+side);
            }
        }
        void AddKerbs(Transform parent){
            var vertices=new System.Collections.Generic.List<Vector3>();var red=new System.Collections.Generic.List<int>();var white=new System.Collections.Generic.List<int>();
            for(int i=0;i<256;i++)foreach(int side in new[]{-1,1}){
                float t=i/256f,u=(i+1)/256f;Vector3 a=Point(t)+Vector3.up*.006f,b=Point(u)+Vector3.up*.006f,sa=Vector3.Cross(Vector3.up,Tangent(t))*side,sb=Vector3.Cross(Vector3.up,Tangent(u))*side;int v=vertices.Count;
                vertices.Add(a+sa*.30f*Size);vertices.Add(a+sa*.35f*Size);vertices.Add(b+sb*.30f*Size);vertices.Add(b+sb*.35f*Size);
                var triangles=(i/3)%2==0?red:white;triangles.AddRange(new[]{v,v+2,v+1,v+1,v+2,v+3});
            }
            var mesh=new Mesh();mesh.SetVertices(vertices);mesh.subMeshCount=2;mesh.SetTriangles(red,0);mesh.SetTriangles(white,1);mesh.RecalculateNormals();
            var kerbs=new GameObject("Grand Prix red white kerbs",typeof(MeshFilter),typeof(MeshRenderer));kerbs.transform.SetParent(parent,false);kerbs.GetComponent<MeshFilter>().sharedMesh=mesh;kerbs.GetComponent<MeshRenderer>().sharedMaterials=new[]{kerbRed,kerbWhite};kerbs.AddComponent<TrackMeshLifetime>().ownedMesh=mesh;
        }
        public void OnPlaced(){
            if(previewTrack)Destroy(previewTrack.gameObject);if(circuit)Destroy(circuit.gameObject);boosts.Clear();
            if(Mode==RaceMode.Track){circuit=new GameObject("Anchored race circuit").transform;circuit.SetParent(game.SurfaceTransform,false);BuildRoad(circuit,false);DirectionMarks(circuit,false);AddKerbs(circuit);
                gate=new GameObject("Next checkpoint").transform;gate.SetParent(circuit,false);var ring=gate.gameObject.AddComponent<LineRenderer>();ring.useWorldSpace=false;ring.loop=true;ring.positionCount=32;ring.startWidth=ring.endWidth=.015f;ring.sharedMaterial=edgeMaterial;for(int i=0;i<32;i++){float a=i*Mathf.PI*2/32;ring.SetPosition(i,new Vector3(Mathf.Cos(a)*.25f*Size,.25f*Size+Mathf.Sin(a)*.25f*Size,0));}
            }
            Stage=RaceStage.Ready;RestartState();
        }
        void RestartState(){
            progress.Configure(RaceLaps);completed=false;RaceTime=outside=ghostTravel=crashLeft=playerParameter=0;crashes=0;if(blast)Destroy(blast.gameObject);game.ResetRaceStats();var arcade=GetComponent<RoomArcade>();if(arcade)arcade.ResetRun();
            if(Mode==RaceMode.Track){game.PlayerCar.localPosition=Point(0);game.PlayerCar.localRotation=Quaternion.LookRotation(Tangent(0),Vector3.up);UpdateGate();RespawnBoosts();CreateGhost();}
            else{game.PlayerCar.localPosition=Vector3.zero;game.PlayerCar.localRotation=Quaternion.identity;game.Scatter();}
            previous=game.PlayerCar.position;game.Halt();
        }
        void UpdateGate(){float t=progress.Next/16f;gate.localPosition=Point(t);gate.localRotation=Quaternion.LookRotation(Tangent(t),Vector3.up);}
        void RespawnBoosts(){
            foreach(var b in boosts)if(b)Destroy(b.gameObject);boosts.Clear();
            foreach(float t in new[]{.18f,.48f,.78f}){var b=GameObject.CreatePrimitive(PrimitiveType.Sphere);b.name="Boost pickup";Destroy(b.GetComponent<Collider>());b.transform.SetParent(circuit,false);b.transform.localPosition=Point(t)+Vector3.up*.12f;b.transform.localScale=new Vector3(.10f,.15f,.10f);b.GetComponent<Renderer>().sharedMaterial=edgeMaterial;boosts.Add(b.transform);}
        }
        public void StartRace(){if(Stage!=RaceStage.Ready)return;Stage=RaceStage.Racing;game.CloseScanMenu();game.HideScan();game.Halt();}
        public void RaceAgain(){if(!game.HasCar)return;game.ResumeRace();RestartState();Stage=RaceStage.Ready;}
        public void Reposition(){game.ShowScanForPlacement();game.Replace();Stage=RaceStage.Placement;}
        public void MainMenu(){game.Replace();Stage=RaceStage.Menu;}
        public void Cleanup(){crashLeft=0;if(blast)Destroy(blast.gameObject);ghost=null;pace=null;if(circuit)Destroy(circuit.gameObject);if(previewTrack)Destroy(previewTrack.gameObject);circuit=gate=previewTrack=null;boosts.Clear();}
        public void Finish(bool raceCompleted=false){
            if(Stage!=RaceStage.Racing)return;
            completed=raceCompleted;
            if(Mode==RaceMode.Track&&completed&&(!PlayerPrefs.HasKey(BestKey)||RaceTime<PlayerPrefs.GetFloat(BestKey))){PlayerPrefs.SetFloat(BestKey,RaceTime);PlayerPrefs.Save();}
            Stage=RaceStage.Results;game.Halt();
        }
        public void ToggleSound(){Sound=!Sound;PlayerPrefs.SetInt("ARRacing.Sound",Sound?1:0);PlayerPrefs.Save();}
        public void ToggleVibration(){Vibration=!Vibration;PlayerPrefs.SetInt("ARRacing.Vibration",Vibration?1:0);PlayerPrefs.Save();}
        public void PickupFeedback(){Flash=.22f;if(Sound)audioSource.PlayOneShot(pickupSound);if(Vibration&&Application.isMobilePlatform)Handheld.Vibrate();}
        void LateUpdate(){
            Flash=Mathf.Max(0,Flash-Time.unscaledDeltaTime);
            if(!game.HasCar||!game.CanRunClock||Stage!=RaceStage.Racing){if(game.PlayerCar)previous=game.PlayerCar.position;return;}RaceTime+=Time.deltaTime;
            if(Mode==RaceMode.Obstacle&&RaceTime>=60){Finish();return;}
            if(Mode!=RaceMode.Track)return;
            UpdateGhost(Time.deltaTime);
            if(Crashing){
                crashLeft=Mathf.Max(0,crashLeft-Time.deltaTime);game.PlayerCar.localPosition+=Vector3.down*Time.deltaTime*1.6f;game.PlayerCar.Rotate(110*Time.deltaTime,40*Time.deltaTime,0,Space.Self);
                if(blast)blast.localScale=Vector3.one*(1.35f-crashLeft)*.8f;
                if(crashLeft<=0){if(blast)Destroy(blast.gameObject);RecoverToGate();}
                return;
            }
            Vector3 local=game.PlayerCar.localPosition;float nearest=float.PositiveInfinity;
            for(int i=0;i<256;i++){Vector3 p=Point(i/256f),q=Point((i+1)/256f);float gap=CircuitShape.SegmentDistance(local.x,local.z,p.x,p.z,q.x,q.z);if(gap<nearest){nearest=gap;var segment=q-p;playerParameter=(i+Mathf.Clamp01(Vector3.Dot(local-p,segment)/Mathf.Max(.000001f,segment.sqrMagnitude)))/256f;}}
            outside=nearest>.30f*Size+.10f?outside+Time.deltaTime:0;
            if(CircuitShape.OffRoad(nearest,.30f*Size,outside)){Crash();return;}
            Vector3 a=circuit.InverseTransformPoint(previous),b=circuit.InverseTransformPoint(game.PlayerCar.position),target=Point(progress.Next/16f),ab=b-a;
            float along=Mathf.Clamp01(Vector3.Dot(target-a,ab)/Mathf.Max(.000001f,ab.sqrMagnitude));
            if(Vector3.Distance(target,a+ab*along)<.30f*Size&&Vector3.Dot(ab,Tangent(progress.Next/16f))>0){
                int laps=progress.Laps;progress.Visit(progress.Next,16);game.Award(100);
                if(progress.Finished){Finish(true);return;}UpdateGate();if(progress.Laps!=laps)RespawnBoosts();
            }
            foreach(var pickup in boosts)if(pickup&&pickup.gameObject.activeSelf){pickup.Rotate(0,90*Time.deltaTime,0);if(Vector3.Distance(pickup.position,game.PlayerCar.position+game.SurfaceNormal*.1f)<.22f){pickup.gameObject.SetActive(false);game.CollectBoost();}}
            previous=game.PlayerCar.position;
        }
        public void RecoverToGate(){if(Mode!=RaceMode.Track)return;crashLeft=0;if(blast)Destroy(blast.gameObject);int segment=(progress.Next+15)%16;float t=segment/16f;game.Halt();game.PlayerCar.localPosition=Point(t);game.PlayerCar.localRotation=Quaternion.LookRotation(Tangent(t),Vector3.up);previous=game.PlayerCar.position;outside=0;}
        void CreateGhost(){
            if(ghost)Destroy(ghost.gameObject);pace=new CircuitPace(TrackType,Size);
            ghost=Instantiate(game.PlayerCar.gameObject,circuit).transform;ghost.name="Ghost pace rival (non-colliding)";
            foreach(var renderer in ghost.GetComponentsInChildren<Renderer>())renderer.sharedMaterial=ghostMaterial;
            foreach(var collider in ghost.GetComponentsInChildren<Collider>())Destroy(collider);
            foreach(var trail in ghost.GetComponentsInChildren<TrailRenderer>()){trail.emitting=false;trail.Clear();}
            UpdateGhost(0);
        }
        void UpdateGhost(float dt){
            if(!ghost||pace==null)return;ghostTravel=Mathf.Min(pace.Length*RaceLaps,ghostTravel+GhostSpeed*dt);
            float t=ghostTravel>=pace.Length*RaceLaps?0:pace.Parameter(ghostTravel);
            ghost.localPosition=Point(t)+Vector3.up*.025f;ghost.localRotation=Quaternion.LookRotation(Tangent(t),Vector3.up);
        }
        void Crash(){
            crashes++;crashLeft=1.25f;game.Halt();PickupFeedback();
            var effect=GameObject.CreatePrimitive(PrimitiveType.Sphere);effect.name="Arcade crash burst";Destroy(effect.GetComponent<Collider>());blast=effect.transform;blast.SetParent(circuit,false);blast.position=game.PlayerCar.position+game.SurfaceNormal*.1f;blast.localScale=Vector3.one*.08f;effect.GetComponent<Renderer>().sharedMaterial=crashMaterial;
        }
        void OnDestroy(){Cleanup();if(kerbRed)Destroy(kerbRed);if(kerbWhite)Destroy(kerbWhite);if(ghostMaterial)Destroy(ghostMaterial);if(crashMaterial)Destroy(crashMaterial);if(pickupSound)Destroy(pickupSound);if(previewMaterial)Destroy(previewMaterial);if(roadMaterial)Destroy(roadMaterial);if(edgeMaterial)Destroy(edgeMaterial);}
    }
}






