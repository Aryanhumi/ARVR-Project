using System;
namespace ARRacing
{
    public enum RaceMode { Free, Track, Obstacle }
    public enum RaceStage { Menu, Placement, Ready, Racing, Results }
    public enum HudScreen { None, Main, Placement, Ready, Racing, Options, Manual, Results }
    public static class HudScreenRules
    {
        public static HudScreen Resolve(RaceStage stage,bool options,bool scanning,bool manual,bool paused,bool hasCar)
        {
            if(options||scanning)return HudScreen.Options;
            if(manual)return HudScreen.Manual;
            if(stage==RaceStage.Menu)return HudScreen.Main;
            if(stage==RaceStage.Results)return HudScreen.Results;
            if(stage==RaceStage.Placement)return HudScreen.Placement;
            if(stage==RaceStage.Ready&&hasCar)return HudScreen.Ready;
            if(stage==RaceStage.Racing&&hasCar)return paused?HudScreen.Ready:HudScreen.Racing;
            return HudScreen.None;
        }
    }
    public sealed class CircuitProgress
    {
        public int Next {get;private set;}=1;
        public int Laps {get;private set;}
        public int TargetLaps {get;private set;}=3;
        public bool Finished=>Laps>=TargetLaps;
        public void Configure(int laps){TargetLaps=laps==10?10:laps==5?5:3;Reset();}
        public bool Visit(int index,int count){if(Finished||index!=Next)return false;if(index==0){Laps++;Next=1;}else Next=(Next+1)%count;return true;}
        public void Reset(){Next=1;Laps=0;}
    }
    public sealed class CircuitPace
    {
        const int Count=512;
        readonly float[] distance=new float[Count+1];
        public float Length=>distance[Count];
        public CircuitPace(int type,float scale){
            CircuitShape.Point(type,0,out float ax,out float az);
            for(int i=1;i<=Count;i++){CircuitShape.Point(type,i/(float)Count,out float bx,out float bz);float x=bx-ax,z=bz-az;distance[i]=distance[i-1]+(float)Math.Sqrt(x*x+z*z)*scale;ax=bx;az=bz;}
        }
        public float Parameter(float metres){
            float d=metres-(float)Math.Floor(metres/Length)*Length;int low=0,high=Count;
            while(high-low>1){int mid=(low+high)/2;if(distance[mid]<=d)low=mid;else high=mid;}
            return (low+(d-distance[low])/Math.Max(.000001f,distance[high]-distance[low]))/Count;
        }
        public float DistanceAt(float t){float p=Math.Max(0,Math.Min(1,t))*Count;int i=Math.Min(Count-1,(int)p);return distance[i]+(distance[i+1]-distance[i])*(p-i);}
    }
    public static class CircuitShape
    {
        // Original Grand Prix-inspired layouts; not replicas of licensed circuits.
        static readonly float[][] layouts={
            new float[]{-2,-1.3f, 0,-1.3f, 2,-1.3f, 2.5f,-.8f, 2.3f,.05f, 1.1f,.25f, 1.6f,1.25f, .6f,1.6f, -.5f,1.4f, -.6f,.5f, -1.5f,.7f, -2.4f,.15f},
            new float[]{-2.2f,-1.4f, -.5f,-1.4f, 1.7f,-1.4f, 2.5f,-.8f, 1.7f,-.15f, 2.1f,.85f, 1.1f,1.5f, .2f,.65f, -.6f,1.5f, -1.7f,1.3f, -2.5f,.4f, -1.65f,-.35f},
            new float[]{-2.3f,-1.3f, -.5f,-1.3f, 1.8f,-1.3f, 2.5f,-.65f, 2,0, 2.5f,.85f, 1.5f,1.5f, .5f,1.3f, -.2f,.55f, -.9f,1.3f, -2,1.5f, -2.5f,.6f, -1.5f,.05f}
        };
        public static void Point(int type,float t,out float x,out float z)
        {
            var p=layouts[Math.Max(0,Math.Min(2,type))];int count=p.Length/2;
            float f=(t-(float)Math.Floor(t))*count;int i=(int)f;float u=f-i;
            int a=((i+count-1)%count)*2,b=i*2,c=((i+1)%count)*2,d=((i+2)%count)*2;
            x=Catmull(p[a],p[b],p[c],p[d],u);z=Catmull(p[a+1],p[b+1],p[c+1],p[d+1],u);
        }
        static float Catmull(float a,float b,float c,float d,float t)=>.5f*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t);
        public static float Size(float value)=>Math.Max(.75f,Math.Min(4,value));
        public static bool OffRoad(float centreDistance,float halfWidth,float seconds)=>centreDistance>halfWidth+.10f&&seconds>=.20f;
        public static float SegmentDistance(float px,float pz,float ax,float az,float bx,float bz)
        {float x=bx-ax,z=bz-az;float t=Math.Max(0,Math.Min(1,((px-ax)*x+(pz-az)*z)/Math.Max(.000001f,x*x+z*z)));x=px-ax-x*t;z=pz-az-z*t;return (float)Math.Sqrt(x*x+z*z);}
        public static float SmoothAxis(float current,float target,float dt)
        {return current+(target-current)*(1-(float)Math.Exp(-12*Math.Max(0,Math.Min(.05f,dt))));}
    }
}



