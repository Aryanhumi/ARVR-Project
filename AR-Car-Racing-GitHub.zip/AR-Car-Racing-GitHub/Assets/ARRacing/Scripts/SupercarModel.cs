using System.Collections.Generic;
using UnityEngine;

namespace ARRacing
{
    public static class SupercarModel
    {
        static GameObject Part(string name,PrimitiveType type,Transform parent,Vector3 position,Vector3 scale,Material material)
        {
            var g=GameObject.CreatePrimitive(type);g.name=name;g.transform.SetParent(parent,false);g.transform.localPosition=position;g.transform.localScale=scale;
            g.GetComponent<Renderer>().sharedMaterial=material;Object.Destroy(g.GetComponent<Collider>());return g;
        }
        static Material Finish(Material source,Color color,float metallic,float smoothness)
        {var m=new Material(source);m.color=color;m.SetFloat("_Metallic",metallic);m.SetFloat("_Smoothness",smoothness);return m;}
        public static void Build(Transform car,Material source,Material black)
        {
            var paint=Finish(source,new Color(.98f,.13f,.025f),.65f,.85f);
            var carbon=Finish(black,new Color(.018f,.022f,.03f),.35f,.55f);
            var glass=Finish(source,new Color(.045f,.12f,.17f),.65f,.97f);
            var alloy=Finish(source,new Color(.65f,.7f,.77f),.9f,.8f);
            var white=Finish(source,new Color(.9f,.97f,1),0,.8f);white.EnableKeyword("_EMISSION");white.SetColor("_EmissionColor",new Color(.7f,.9f,1));
            var red=Finish(source,new Color(1,.015f,.025f),0,.8f);red.EnableKeyword("_EMISSION");red.SetColor("_EmissionColor",new Color(1,.01f,.015f));
            Loft("Sculpted supercar body",car,new[]{-.21f,-.16f,-.04f,.12f,.205f},new[]{.087f,.112f,.108f,.1f,.081f},new[]{.073f,.093f,.085f,.064f,.046f},.027f,paint);
            Loft("Panoramic canopy",car,new[]{-.115f,-.07f,.03f,.10f},new[]{.073f,.068f,.065f,.076f},new[]{.087f,.147f,.137f,.073f},.073f,glass);
            Part("Carbon roof",PrimitiveType.Cube,car,new Vector3(0,.144f,-.025f),new Vector3(.108f,.007f,.07f),carbon).transform.localRotation=Quaternion.Euler(5,0,0);
            Part("Front splitter",PrimitiveType.Cube,car,new Vector3(0,.027f,.19f),new Vector3(.21f,.012f,.055f),carbon);
            Part("Front grille",PrimitiveType.Cube,car,new Vector3(0,.039f,.208f),new Vector3(.11f,.018f,.008f),carbon);
            Part("Rear diffuser",PrimitiveType.Cube,car,new Vector3(0,.033f,-.207f),new Vector3(.17f,.022f,.023f),carbon);
            Part("Rear light bar",PrimitiveType.Cube,car,new Vector3(0,.068f,-.213f),new Vector3(.151f,.008f,.005f),red);
            Part("Rear wing",PrimitiveType.Cube,car,new Vector3(0,.112f,-.18f),new Vector3(.24f,.012f,.047f),carbon);
            for(int i=-2;i<=2;i++)Part("Diffuser fin",PrimitiveType.Cube,car,new Vector3(i*.027f,.026f,-.215f),new Vector3(.004f,.025f,.031f),carbon);
            foreach(float side in new[]{-1f,1f})
            {
                Part("Wing bracket",PrimitiveType.Cube,car,new Vector3(side*.067f,.088f,-.18f),new Vector3(.009f,.045f,.01f),alloy);
                var light=Part("LED headlight",PrimitiveType.Cube,car,new Vector3(side*.066f,.057f,.18f),new Vector3(.043f,.006f,.02f),white);light.transform.localRotation=Quaternion.Euler(0,side*17,0);
                Part("Side air intake",PrimitiveType.Cube,car,new Vector3(side*.108f,.058f,-.058f),new Vector3(.005f,.025f,.07f),carbon);
                Part("Side skirt",PrimitiveType.Cube,car,new Vector3(side*.111f,.027f,0),new Vector3(.012f,.012f,.24f),carbon);
                var mirror=Part("Mirror",PrimitiveType.Sphere,car,new Vector3(side*.103f,.109f,.032f),new Vector3(.035f,.015f,.024f),carbon);
                foreach(float z in new[]{-.128f,.128f})
                {
                    var axle=new GameObject("Wheel").transform;axle.SetParent(car,false);axle.localPosition=new Vector3(side*.111f,.046f,z);axle.localRotation=Quaternion.Euler(0,0,90);
                    Part("Performance tyre",PrimitiveType.Cylinder,axle,Vector3.zero,new Vector3(.091f,.016f,.091f),carbon);
                    float exterior=-side;
                    Part("Alloy rim",PrimitiveType.Cylinder,axle,new Vector3(0,exterior*.017f,0),new Vector3(.068f,.002f,.068f),alloy);
                    Part("Brake disc",PrimitiveType.Cylinder,axle,new Vector3(0,exterior*.019f,0),new Vector3(.052f,.001f,.052f),carbon);
                    Part("Wheel hub",PrimitiveType.Cylinder,axle,new Vector3(0,exterior*.023f,0),new Vector3(.014f,.004f,.014f),alloy);
                    for(int spoke=0;spoke<5;spoke++)
                    {
                        float a=spoke*Mathf.PI*2/5;
                        var s=Part("Forged spoke",PrimitiveType.Cube,axle,new Vector3(Mathf.Cos(a)*.02f,exterior*.022f,Mathf.Sin(a)*.02f),new Vector3(.032f,.004f,.006f),alloy);
                        s.transform.localRotation=Quaternion.Euler(0,-a*Mathf.Rad2Deg,0);
                    }
                }
            }
        }
        static void Loft(string name,Transform parent,float[] z,float[] widths,float[] tops,float bottom,Material material)
        {
            var points=new List<Vector3>();var triangles=new List<int>();
            for(int i=0;i<z.Length;i++)
            {
                float w=widths[i],t=tops[i],b=Mathf.Min(bottom,t-.012f),bevel=Mathf.Min(.012f,(t-b)*.3f);
                points.AddRange(new[]{new Vector3(-w*.76f,t,z[i]),new Vector3(w*.76f,t,z[i]),new Vector3(w,t-bevel,z[i]),new Vector3(w,b+bevel*.6f,z[i]),new Vector3(w*.76f,b,z[i]),new Vector3(-w*.76f,b,z[i]),new Vector3(-w,b+bevel*.6f,z[i]),new Vector3(-w,t-bevel,z[i])});
                if(i==0)continue;
                for(int j=0;j<8;j++){int a=(i-1)*8+j,b0=i*8+j,c=(i-1)*8+(j+1)%8,d=i*8+(j+1)%8;triangles.AddRange(new[]{a,b0,c,c,b0,d});}
            }
            for(int j=1;j<7;j++){triangles.AddRange(new[]{0,j,j+1});int end=(z.Length-1)*8;triangles.AddRange(new[]{end,end+j+1,end+j});}
            var mesh=new Mesh{name=name};mesh.SetVertices(points);mesh.SetTriangles(triangles,0);mesh.RecalculateNormals();mesh.RecalculateBounds();
            var g=new GameObject(name,typeof(MeshFilter),typeof(MeshRenderer));g.transform.SetParent(parent,false);g.GetComponent<MeshFilter>().sharedMesh=mesh;g.GetComponent<MeshRenderer>().sharedMaterial=material;
        }
    }
}
