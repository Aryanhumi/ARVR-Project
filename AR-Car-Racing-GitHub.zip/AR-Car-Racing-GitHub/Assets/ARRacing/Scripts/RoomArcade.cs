using System.Collections.Generic;
using UnityEngine;

namespace ARRacing
{
    // Adds an arcade presentation without placing a fixed racing road over the room.
    public class RoomArcade : MonoBehaviour
    {
        public ARRaceGame game;
        Transform styledCar, goal;
        readonly List<Transform> wheels=new List<Transform>();
        readonly List<TrailRenderer> trails=new List<TrailRenderer>();
        Material cyan, pink, navy, silver;
        float missionTime=35, celebration, retryAt;
        int gates, combo;
        int areaRevision=-1;
        Vector3 previous;
        Camera cameraView;
        bool sceneryReady;

        Material Glow(Color color)
        {
            var template=Resources.Load<Material>("ARRacing/Scan");
            var m=template?new Material(template):new Material(Shader.Find("Universal Render Pipeline/Unlit"));m.color=color;return m;
        }
        GameObject Shape(string name,PrimitiveType type,Transform parent,Vector3 position,Vector3 scale,Material mat)
        {
            var g=GameObject.CreatePrimitive(type);g.name=name;g.transform.SetParent(parent,false);g.transform.localPosition=position;g.transform.localScale=scale;
            g.GetComponent<Renderer>().sharedMaterial=mat;Destroy(g.GetComponent<Collider>());return g;
        }
        void Start()
        {
            cyan=Glow(new Color(.02f,.85f,1));pink=Glow(new Color(1,.08f,.48f));navy=Glow(new Color(.035f,.055f,.12f));silver=Glow(new Color(.72f,.85f,.98f));
            cameraView=game.raceCamera;
        }
        void StyleCar(Transform car)
        {
            styledCar=car;previous=car.position;wheels.Clear();trails.Clear();
            foreach(float side in new[]{-1f,1f})
            {
                var nozzle=new GameObject("Nitro exhaust");nozzle.transform.SetParent(car,false);nozzle.transform.localPosition=new Vector3(side*.055f,.05f,-.225f);
                var trail=nozzle.AddComponent<TrailRenderer>();trail.sharedMaterial=cyan;trail.time=.2f;trail.startWidth=.028f;trail.endWidth=0;trail.minVertexDistance=.015f;trail.emitting=false;trails.Add(trail);
            }
            foreach(Transform child in car)if(child.name=="Wheel")wheels.Add(child);
        }
        void Scenery()
        {
            sceneryReady=true;
            var scenery=new GameObject("Desktop neon plaza").transform;
            scenery.SetPositionAndRotation(game.SurfaceTransform.position,game.SurfaceTransform.rotation);
            for(int i=0;i<24;i++)
            {
                float a=i*Mathf.PI*2/24;float h=.4f+(i%5)*.23f;
                var tower=Shape("Skyline tower",PrimitiveType.Cube,scenery,new Vector3(Mathf.Cos(a)*5,h/2,Mathf.Sin(a)*5),new Vector3(.48f,h,.48f),navy);
                Shape("Tower neon",PrimitiveType.Cube,tower.transform,new Vector3(0,.35f,-.505f),new Vector3(.7f,.025f,.012f),i%2==0?cyan:pink);
            }
            foreach(float side in new[]{-1f,1f})
            {
                Shape("Plaza light",PrimitiveType.Cube,scenery,new Vector3(side*3.95f,.012f,0),new Vector3(.025f,.02f,8),cyan);
                Shape("Plaza light",PrimitiveType.Cube,scenery,new Vector3(0,.012f,side*3.95f),new Vector3(8,.02f,.025f),pink);
            }
            cameraView.backgroundColor=new Color(.018f,.025f,.06f);
            cameraView.fieldOfView=58;
        }
        public void ResetRun(){gates=combo=0;missionTime=35;celebration=retryAt=0;if(goal)Destroy(goal.gameObject);goal=null;}
        void NewGoal()
        {
            if(goal)Destroy(goal.gameObject);
            Vector3 origin=styledCar.position;
            for(int i=0;i<48;i++)
            {
                float u=((i*.618034f+.19f+gates*.13f)%1-.5f)*.8f,v=((i*.414214f+.31f)%1-.5f)*.8f;
                Vector3 point=game.SpawnPoint(u,v);
                if(Vector3.Distance(point,origin)<.35f)continue;
                if(!game.CanSpawn(point))continue;
                goal=new GameObject("Checkpoint portal").transform;goal.SetParent(game.SurfaceTransform,false);goal.position=point;
                goal.rotation=Quaternion.LookRotation(Vector3.ProjectOnPlane(origin-point,game.SurfaceNormal),game.SurfaceNormal);
                var ring=goal.gameObject.AddComponent<LineRenderer>();ring.useWorldSpace=false;ring.loop=true;ring.positionCount=48;
                ring.startWidth=ring.endWidth=.018f;ring.sharedMaterial=cyan;
                for(int n=0;n<48;n++){float t=n*Mathf.PI*2/48;ring.SetPosition(n,new Vector3(Mathf.Cos(t)*.25f,.27f+Mathf.Sin(t)*.25f,0));}
                foreach(float side in new[]{-1f,1f})Shape("Portal foot",PrimitiveType.Cylinder,goal,new Vector3(side*.26f,.025f,0),new Vector3(.07f,.025f,.07f),pink);
                missionTime=35;return;
            }
            retryAt=Time.time+2;
        }
        void Update()
        {
            if(!game.PlayerCar){if(goal)Destroy(goal.gameObject);styledCar=null;return;}
            if(styledCar!=game.PlayerCar){if(goal)Destroy(goal.gameObject);StyleCar(game.PlayerCar);retryAt=0;}
            if(areaRevision!=game.SurfaceRevision){areaRevision=game.SurfaceRevision;if(goal)Destroy(goal.gameObject);goal=null;if(!game.RoomDrive)combo=0;retryAt=0;}

            if(!game.RoomDrive&&goal){Destroy(goal.gameObject);goal=null;}
            if(goal)goal.gameObject.SetActive(true);
            if(game.DesktopDriving&&!sceneryReady)Scenery();
            if(game.RoomDrive&&game.Flow.Stage==RaceStage.Racing&&!goal&&Time.time>=retryAt)NewGoal();
            foreach(var t in trails)t.emitting=game.IsDriving&&game.BoostActive&&Mathf.Abs(game.DriveSpeed)>.1f;
            if(!game.IsDriving)return;
            foreach(var w in wheels)w.Rotate(0,game.DriveSpeed*Time.deltaTime*900,0,Space.Self);
            celebration=Mathf.Max(0,celebration-Time.deltaTime);
            if(goal)
            {
                missionTime-=Time.deltaTime;
                var p=Vector3.ProjectOnPlane(styledCar.position-goal.position,game.SurfaceNormal);
                if(p.magnitude<.24f)
                {
                    gates++;combo++;game.Award(150+Mathf.Min(combo,5)*25);celebration=1.5f;Burst(goal.position+game.SurfaceNormal*.2f);NewGoal();
                }
                else if(missionTime<=0){combo=0;NewGoal();}
            }
            previous=styledCar.position;
        }
        void Burst(Vector3 position)
        {
            for(int i=0;i<12;i++)
            {
                var spark=Shape("Checkpoint spark",PrimitiveType.Sphere,null,position,new Vector3(.025f,.025f,.025f),i%2==0?cyan:pink);
                var motion=spark.AddComponent<ArcadeSpark>();motion.velocity=Quaternion.AngleAxis(i*30,game.SurfaceNormal)*game.SurfaceForward*.45f+game.SurfaceNormal*.5f;motion.gravity=-game.SurfaceNormal;
                Destroy(spark,1);
            }
        }
        void LateUpdate()
        {
            if(!styledCar||!game.DesktopDriving)return;
            // Only the desktop practice camera follows the car; AR camera remains device tracked.
            Vector3 target=styledCar.position-styledCar.forward*.95f+game.SurfaceNormal*.68f;
            cameraView.transform.position=Vector3.Lerp(cameraView.transform.position,target,1-Mathf.Exp(-7*Time.deltaTime));
            cameraView.transform.rotation=Quaternion.Slerp(cameraView.transform.rotation,Quaternion.LookRotation(styledCar.position+styledCar.forward*.3f+game.SurfaceNormal*.08f-cameraView.transform.position,game.SurfaceNormal),1-Mathf.Exp(-9*Time.deltaTime));
            cameraView.fieldOfView=Mathf.Lerp(cameraView.fieldOfView,game.BoostActive?68:58,Time.deltaTime*3);
        }
        void OnGUI()
        {
            if(!styledCar||!game.RoomDrive||!game.IsDriving)return;
            var old=GUI.matrix;GUI.matrix=Matrix4x4.TRS(Vector3.zero,Quaternion.identity,new Vector3(Screen.width/1100f,Screen.height/650f,1));
            GUI.skin.box.fontSize=19;
            GUI.Box(new Rect(360,100,380,32),celebration>0?"CHECKPOINT!  COMBO x"+combo:goal?$"PORTAL RUN   {gates} cleared   /   {Mathf.CeilToInt(missionTime)}s":"Collect coins and explore the room");
            if(goal)
            {
                Vector3 direction=goal.position-styledCar.position;
                float turn=Vector3.SignedAngle(styledCar.forward,direction,game.SurfaceNormal);
                string hint=Mathf.Abs(turn)<20?"STRAIGHT AHEAD":turn<0?"TURN LEFT":"TURN RIGHT";
                GUI.Box(new Rect(410,136,280,28),hint+"   "+direction.magnitude.ToString("0.0")+"m");
            }
            GUI.matrix=old;
        }
    }
    public class ArcadeSpark:MonoBehaviour
    {
        public Vector3 velocity,gravity=Vector3.down;
        void Update(){transform.position+=velocity*Time.deltaTime;velocity+=gravity*Time.deltaTime;transform.localScale*=Mathf.Exp(-2*Time.deltaTime);}
    }
}



