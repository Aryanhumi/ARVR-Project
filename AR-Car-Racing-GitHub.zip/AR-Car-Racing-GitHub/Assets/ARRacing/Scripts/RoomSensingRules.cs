using System;
namespace ARRacing
{
    // Spatial exceptions, not semantic object identities. Reset when the AR map resets.
    public sealed class ObstacleExclusions
    {
        readonly System.Collections.Generic.List<(float x,float y,float z,float radius)> zones=new System.Collections.Generic.List<(float,float,float,float)>();
        public int Count=>zones.Count;
        public void Add(float x,float y,float z,float radius=.35f){if(zones.Count==16)zones.RemoveAt(0);zones.Add((x,y,z,Math.Max(.05f,Math.Min(1,radius))));}
        public bool Contains(float x,float y,float z){foreach(var p in zones){float dx=x-p.x,dy=y-p.y,dz=z-p.z;if(dx*dx+dy*dy+dz*dz<=p.radius*p.radius)return true;}return false;}
        public bool Undo(){if(zones.Count==0)return false;zones.RemoveAt(zones.Count-1);return true;}
        public void Clear(){zones.Clear();}
    }
    public static class SurfaceSelection
    {
        public static bool Accept(int filter,float upDot)=>filter==0||(filter==1&&upDot>.7f)||(filter==2&&Math.Abs(upDot)<.7f)||(filter==3&&upDot<-.7f);
        public static bool JunctionPatch(float width,float length)=>width>=.35f&&length>=.35f&&width*length>=.35f;
    }
    public static class DepthCollisionRules
    {
        public static bool DrivingSurface(float normalDistance)=>Math.Abs(normalDistance)<=.055f;
        public static bool ValidDepth(float metres)=>!float.IsNaN(metres)&&!float.IsInfinity(metres)&&metres>.15f&&metres<8;
        public static bool InsideCar(float x,float height,float z)=>Math.Abs(x)<.16f&&Math.Abs(z)<.32f&&height>.035f&&height<.23f;
        public static bool NearbyDepth(float expected,float measured)=>ValidDepth(measured)&&Math.Abs(expected-measured)<.22f;
        public static void ImageUv(float x,float y,float xx,float yx,float xy,float yy,float tx,float ty,out float u,out float v)
        {u=x*xx+y*yx+tx;v=x*xy+y*yy+ty;}
    }
}

