using System.Collections.Generic;

namespace ARRacing
{
    public sealed class DriveSessionState
    {
        public bool UserPaused { get; private set; }
        public bool ApplicationPaused { get; private set; }
        public bool HasFocus { get; private set; }=true;
        public bool CanDrive=>!UserPaused&&!ApplicationPaused&&HasFocus;
        public void TogglePause(){UserPaused=!UserPaused;}
        public void ResetUserPause(){UserPaused=false;}
        public void SetApplicationPause(bool value){ApplicationPaused=value;}
        public void SetFocus(bool value){HasFocus=value;}
    }
    public static class DriveSwipe
    {
        public static DriveControl Resolve(bool vertical,float displacement,DriveControl initial)
        {
            if(System.Math.Abs(displacement)<.06f)return initial;
            return vertical?(displacement>0?DriveControl.Forward:DriveControl.Reverse):(displacement>0?DriveControl.Right:DriveControl.Left);
        }
    }
    public static class DriveMotion
    {
        public static float Step(float speed,float throttle,bool boost,bool brake,float seconds)
        {
            float dt=System.Math.Max(0,System.Math.Min(.05f,seconds));
            float target=brake?0:throttle*(throttle<0?.45f:boost?1.3f:.8f);
            if(!brake&&throttle!=0){float eased=speed+(target-speed)*(1-(float)System.Math.Exp(-6*dt));return System.Math.Abs(eased-target)<.001f?target:eased;}
            float step=(brake?4:throttle==0?.75f:1.6f)*dt;
            return speed<target?System.Math.Min(speed+step,target):System.Math.Max(speed-step,target);
        }
    }
    public enum DriveControl { Left, Right, Forward, Reverse, Brake, Nitro, ForceForward }
    public readonly struct DriveCommand
    {
        public readonly float Steering, Throttle;
        public readonly bool Braking, Boost, ForceForward;
        public DriveCommand(float steering,float throttle,bool braking,bool boost,bool forceForward=false)
        { Steering=steering;Throttle=braking?0:throttle;Braking=braking;Boost=boost&&!braking&&throttle>0;ForceForward=forceForward&&!braking&&throttle>0; }
    }
    // Each finger owns one control. Releasing a different finger cannot cancel it.
    public sealed class DriveInputState
    {
        readonly Dictionary<int,DriveControl> pointers=new Dictionary<int,DriveControl>();
        public void Press(int pointer,DriveControl control){pointers[pointer]=control;}
        public void Release(int pointer,DriveControl control)
        {if(pointers.TryGetValue(pointer,out var active)&&active==control)pointers.Remove(pointer);}
        public bool Held(DriveControl control){foreach(var active in pointers.Values)if(active==control)return true;return false;}
        public void Clear(){pointers.Clear();}
        public DriveCommand Read()
        {
            bool reverse=Held(DriveControl.Reverse),nitro=Held(DriveControl.Nitro),force=Held(DriveControl.ForceForward);
            bool forward=Held(DriveControl.Forward)||((nitro||force)&&!reverse);
            return new DriveCommand((Held(DriveControl.Right)?1:0)-(Held(DriveControl.Left)?1:0),
                (forward?1:0)-(reverse?1:0),Held(DriveControl.Brake),nitro,force&&!reverse);
        }
    }
}


