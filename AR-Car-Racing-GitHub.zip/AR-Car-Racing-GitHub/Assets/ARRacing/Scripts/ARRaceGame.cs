using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.EventSystems;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
namespace ARRacing {
public class ARRaceGame:MonoBehaviour {
 public ARRaycastManager raycasts;public ARPlaneManager planes;public Camera raceCamera;public bool practiceInEditor=true;public int desktopSurfaceMode;
 readonly List<ARRaycastHit> hits=new List<ARRaycastHit>();readonly List<Transform> coins=new List<Transform>();readonly List<RaycastResult> uiHits=new List<RaycastResult>();
 readonly DriveSessionState activity=new DriveSessionState();readonly TrackingGate tracking=new TrackingGate();
 Transform root,car,marker;LineRenderer outline;Material blue,dark,gold,lineMaterial;RaceTouchControls controls;DepthObstacleSensor obstacles;
 Pose preview=new Pose(Vector3.zero,Quaternion.identity),practicePose;ARPlane previewPlane;
 [SerializeField] TrackRaceFlow flow; public TrackRaceFlow Flow {get {if(!flow)flow=GetComponent<TrackRaceFlow>();return flow;}}
 bool placementValid,selectedPreview;float smoothSteer;
 public bool PlacementAvailable=>placementValid&&!lost;public int Score=>score;
 bool placed;bool paused=>activity.UserPaused;
 bool lost,scanMenu,scanning,manual,manualSurface,boost,brake,forceGo,blocked,obstacleStop;float throttle,steer,speed,nitro=100,elapsed,distance,feedbackUntil,manualDistance=1.5f,resetUntil,lastJoin=-10;
 int score,revision,joins,choice;string message="",surface="SURFACE";
 public static bool IsDesktop=>Application.platform!=RuntimePlatform.Android&&Application.platform!=RuntimePlatform.IPhonePlayer;
 bool Practice=>IsDesktop&&(!Application.isEditor||practiceInEditor);
 public bool DesktopDriving=>Practice;public bool HasCar=>placed;public Transform PlayerCar=>car;public Transform SurfaceTransform=>root;
 public Vector3 SurfaceNormal=>root?root.up:preview.rotation*Vector3.up;public Vector3 SurfaceForward=>root?root.forward:preview.rotation*Vector3.forward;public Vector3 SurfaceRight=>root?root.right:preview.rotation*Vector3.right;
 public bool CanRunClock=>placed&&activity.CanDrive&&!lost&&!scanMenu&&!scanning;public bool IsDriving=>CanRunClock&&Flow&&Flow.AllowsDriving;public bool IsPaused=>paused;public bool ShowScan{get;private set;}=true;
 public bool ScanMenuOpen=>scanMenu;public bool ScanningMore=>scanning;public bool ManualWallCalibration=>manual;
 public bool RoomDrive=>!Flow||Flow.Mode!=RaceMode.Track;public float DriveSpeed=>speed;public bool BoostActive=>boost&&throttle>0&&nitro>1;public bool MovementBlocked=>lost||blocked||obstacleStop||!activity.CanDrive;
 public int SurfaceRevision=>revision;public int DetectedSurfaceCount{get;private set;}public string SurfaceName=>surface;
 public string TargetLabel=>"TARGET: "+new[]{"AUTO","FLOOR","WALL","CEILING"}[choice];
 public string ManualWallText=>$"MANUAL WALL: distance estimate {manualDistance:0.00}m. Adjust, then CONFIRM.";
 public string SensorStatus=>obstacles?obstacles.Status:"Depth starting";
 public int IgnoredObstacleCount=>obstacles?obstacles.IgnoredCount:0;
 public bool ObstaclesEnabled=>obstacles&&obstacles.SensingEnabled;
 public string StatsText=>Flow&&Flow.Mode==RaceMode.Track?Flow.Progress+$"   NITRO {nitro:0}%":$"{surface}   DIST {distance:0.0}m   SCORE {score}   NITRO {nitro:0}%   SPEED {Mathf.Abs(speed):0.0}m/s";
 public string FeedbackText=>Time.time<feedbackUntil?message:"";
 string TrackingAdvice=>ARSession.notTrackingReason==NotTrackingReason.InsufficientFeatures?"FEW FEATURES: scan a corner, furniture or textured patch":ARSession.notTrackingReason==NotTrackingReason.InsufficientLight?"LOW LIGHT: improve lighting":ARSession.notTrackingReason==NotTrackingReason.ExcessiveMotion?"MOVE PHONE SLOWLY":"TRACKING RECOVERING: look at previously scanned features";
 public string ControlStatus=>lost?TrackingAdvice:manual?ManualWallText:scanMenu||scanning?"Scan connected surfaces. Free driving has no platform size limit.":!placed?"TAP the exact surface you want. Use TARGET to filter wall/floor/ceiling.":paused?"PAUSED: tap RESUME":obstacleStop?"BLOCKED: NO BLOCK HIT ignores this spot; hold FORCE GO to pass":
  (Flow.Mode==RaceMode.Track?"RACE: ":"DRIVE: ")+(forceGo?"FORCE GO / COLLISION BYPASS":brake?"BRAKE":throttle>0?"FORWARD":throttle<0?"REVERSE":"READY")+(steer<0?" + LEFT":steer>0?" + RIGHT":"")+(Flow.Mode==RaceMode.Obstacle?" / "+SensorStatus:"");
 public string CarHint {get {if(Practice||!car||paused||lost)return "";var v=raceCamera.WorldToViewportPoint(car.position+SurfaceNormal*.08f);if(v.z>0&&v.x>.02f&&v.x<.98f&&v.y>.02f&&v.y<.98f)return "";return "CAR: "+(v.z<=0?"TURN AROUND":v.x<.02f?"LOOK LEFT":v.x>.98f?"LOOK RIGHT":v.y<.02f?"TILT DOWN":"TILT UP");}}
 Material Mat(Color c){var template=Resources.Load<Material>("ARRacing/Surface");var m=template?new Material(template):new Material(Shader.Find("Universal Render Pipeline/Lit"));m.color=c;return m;}
 GameObject Part(string name,PrimitiveType type,Transform parent,Vector3 p,Vector3 scale,Material mat){var g=GameObject.CreatePrimitive(type);g.name=name;g.transform.SetParent(parent,false);g.transform.localPosition=p;g.transform.localScale=scale;g.GetComponent<Renderer>().sharedMaterial=mat;Destroy(g.GetComponent<Collider>());return g;}
 void Start(){
  flow=GetComponent<TrackRaceFlow>();if(!flow)flow=gameObject.AddComponent<TrackRaceFlow>();
  Screen.orientation=ScreenOrientation.LandscapeLeft;Screen.sleepTimeout=SleepTimeout.NeverSleep;
  blue=Mat(new Color(.03f,.65f,.95f));dark=Mat(new Color(.025f,.04f,.065f));gold=Mat(new Color(1,.7f,.08f));var scan=Resources.Load<Material>("ARRacing/Scan");lineMaterial=scan?new Material(scan):new Material(Shader.Find("Universal Render Pipeline/Unlit"));lineMaterial.color=new Color(.1f,1,.65f);
  outline=new GameObject("Selected surface outline").AddComponent<LineRenderer>();outline.useWorldSpace=true;outline.loop=true;outline.startWidth=outline.endWidth=.007f;outline.sharedMaterial=lineMaterial;outline.enabled=false;
  if(Practice){
   foreach(var s in FindObjectsByType<ARSession>())s.enabled=false;planes.enabled=false;
   raceCamera.GetComponent<ARCameraBackground>().enabled=false;raceCamera.GetComponent<ARCameraManager>().enabled=false;raceCamera.GetComponent<UnityEngine.InputSystem.XR.TrackedPoseDriver>().enabled=false;
   raceCamera.clearFlags=CameraClearFlags.SolidColor;raceCamera.backgroundColor=new Color(.025f,.045f,.07f);
   practicePose=new Pose(Vector3.zero,desktopSurfaceMode==1?Quaternion.LookRotation(Vector3.up,Vector3.back):desktopSurfaceMode==2?Quaternion.LookRotation(Vector3.forward,Vector3.down):Quaternion.identity);
   var room=new GameObject("Practice environment").transform;room.SetPositionAndRotation(practicePose.position,practicePose.rotation);
   Part("Practice ground",PrimitiveType.Cube,room,new Vector3(0,-.025f,0),new Vector3(20,.05f,20),Mat(new Color(.12f,.17f,.20f)));
   for(int i=-10;i<=10;i++){Part("Grid",PrimitiveType.Cube,room,new Vector3(i,.002f,0),new Vector3(.006f,.002f,20),dark);Part("Grid",PrimitiveType.Cube,room,new Vector3(0,.002f,i),new Vector3(20,.002f,.006f),dark);}
   NewMarker();raceCamera.transform.position=practicePose.position+practicePose.rotation*new Vector3(0,2.8f,-2.5f);raceCamera.transform.LookAt(practicePose.position,practicePose.rotation*Vector3.up);
  }else NewMarker();
  obstacles=gameObject.AddComponent<DepthObstacleSensor>();obstacles.Initialize(this);
  gameObject.AddComponent<RoomArcade>().game=this;controls=gameObject.AddComponent<RaceTouchControls>();controls.Initialize(this);
 }
 void NewMarker(){if(marker)Destroy(marker.gameObject);marker=Part("Placement preview",PrimitiveType.Cylinder,null,Vector3.zero,new Vector3(.27f,.002f,.27f),blue).transform;marker.gameObject.SetActive(false);}
 bool Eligible(ARPlane p)=>p&&!p.subsumedBy&&p.trackingState==TrackingState.Tracking&&SurfaceSelection.Accept(choice,p.transform.up.y);
 bool TrySurface(Vector2 screen,out Pose pose){
  pose=default;if(!raycasts.Raycast(screen,hits,TrackableType.PlaneWithinPolygon))return false;
  foreach(var hit in hits){var plane=planes.GetPlane(hit.trackableId);if(!Eligible(plane))continue;Vector3 n=plane.transform.up;if(Vector3.Dot(n,raceCamera.transform.position-hit.pose.position)<0)n=-n;
   Vector3 f=Vector3.ProjectOnPlane(raceCamera.transform.up,n);if(f.sqrMagnitude<.001f)f=Vector3.ProjectOnPlane(raceCamera.transform.forward,n);if(f.sqrMagnitude<.001f)f=Vector3.ProjectOnPlane(Vector3.right,n);
   pose=new Pose(hit.pose.position,Quaternion.LookRotation(f.normalized,n));previewPlane=plane;return true;
  }return false;
 }
 bool OverUI(Vector2 p){var e=EventSystem.current;if(!e)return false;uiHits.Clear();e.RaycastAll(new PointerEventData(e){position=p},uiHits);return uiHits.Count>0;}
 void Place(Pose pose){manualSurface=manual;manual=false;root=new GameObject("Free room surface").transform;root.SetPositionAndRotation(pose.position,pose.rotation);if(!Practice)root.gameObject.AddComponent<ARAnchor>();car=new GameObject("Player car").transform;car.SetParent(root,false);SupercarModel.Build(car,blue,dark);placed=true;speed=0;surface=manualSurface?"MANUAL WALL":root.up.y>.7f?"FLOOR":root.up.y<-.7f?"CEILING":"WALL";revision++;if(marker)Destroy(marker.gameObject);if(RoomDrive)Scatter();Flow.OnPlaced();Notice("Placement locked. Press START when ready.");}
 void Update(){
  tracking.Update(Practice||ARSession.state==ARSessionState.SessionTracking,Time.unscaledDeltaTime);lost=!Practice&&!tracking.Ready;
  if(!placed){
   if(manual){UpdateManual();return;}
   bool canScan=Flow.Stage==RaceStage.Placement&&!lost&&!scanMenu&&!scanning&&Time.unscaledTime>=resetUntil;
   if(canScan){
       if(Practice){preview=practicePose;placementValid=true;}
       else if(Pressed()&&!OverUI(ScreenPointer())&&TrySurface(ScreenPointer(),out var tapped)){preview=tapped;selectedPreview=true;placementValid=true;}
       else if(selectedPreview){placementValid=previewPlane&&previewPlane.trackingState==TrackingState.Tracking;}
       else if(!selectedPreview){placementValid=TrySurface(new Vector2(Screen.width*.5f,Screen.height*.5f),out var aimed);if(placementValid)preview=aimed;}
   }else placementValid=false;
   marker.gameObject.SetActive(placementValid);if(placementValid)marker.SetPositionAndRotation(preview.position,Flow.Rotation(preview.rotation));
   Flow.Preview(preview,placementValid);
   DrawOutline();return;
  }
  DrawOutline();ReadInput();if(!IsDriving){speed=0;return;}
  float dt=Mathf.Min(Time.deltaTime,.05f);elapsed+=Time.deltaTime;bool useBoost=boost&&nitro>1&&throttle>0;nitro=Mathf.Clamp(nitro+(useBoost?-27:10)*dt,0,100);speed=DriveMotion.Step(speed,throttle,useBoost,brake,dt);
  smoothSteer=CircuitShape.SmoothAxis(smoothSteer,steer,dt);
  car.Rotate(0,smoothSteer*115*Mathf.Max(.25f,Mathf.Abs(speed)/.8f)*(speed<-.01f?-1:1)*dt,0,Space.Self);
  Vector3 next=car.position+car.forward*speed*dt;var d=next-root.position;var n=SurfaceNormal;SurfaceGeometry.Project(d.x,d.y,d.z,n.x,n.y,n.z,out float x,out float y,out float z);next=root.position+new Vector3(x,y,z);
  obstacleStop=false;blocked=false;
  if(RoomDrive&&TryJoin(next))return;
  if(!forceGo&&Mathf.Abs(speed)>.01f&&obstacles&&obstacles.Blocked(next,Mathf.Sign(speed))){obstacleStop=true;speed=0;return;}
  distance+=Vector3.Distance(car.position,next);car.position=next;
  foreach(var c in coins)if(c&&c.gameObject.activeSelf){c.Rotate(0,100*dt,0);var p=c.localPosition;p.y=.12f+Mathf.Sin(Time.time*3+p.x*4)*.025f;c.localPosition=p;if(Vector3.Distance(c.position,car.position+n*.1f)<.2f){c.gameObject.SetActive(false);score+=50;nitro=Mathf.Min(100,nitro+15);Flow.PickupFeedback();}}
 }
 void DrawOutline(){
  if(Practice||!outline)return;DetectedSurfaceCount=0;ARPlane selected=placed?null:previewPlane;float largest=0;
  foreach(var plane in planes.trackables){if(!Eligible(plane))continue;DetectedSurfaceCount++;if(placed&&SurfaceGeometry.Coplanar(Vector3.Dot(plane.transform.up,SurfaceNormal),Vector3.Dot(plane.transform.position-root.position,SurfaceNormal))){float area=plane.size.x*plane.size.y;if(area>largest){largest=area;selected=plane;}}}
  outline.enabled=ShowScan&&!(Flow&&Flow.Mode==RaceMode.Track&&Flow.Stage==RaceStage.Placement&&placementValid)&&selected&&selected.trackingState==TrackingState.Tracking;if(!outline.enabled)return;var polygon=selected.boundary;outline.positionCount=polygon.Length;for(int i=0;i<polygon.Length;i++)outline.SetPosition(i,selected.transform.TransformPoint(new Vector3(polygon[i].x,.004f,polygon[i].y)));
 }
 public bool CanSpawn(Vector3 p)=>root&&Mathf.Abs(Vector3.Dot(p-root.position,SurfaceNormal))<.08f&&Vector3.Distance(p,car.position)<4;
 public Vector3 SpawnPoint(float u,float v)=>car.position+SurfaceRight*u*3+SurfaceForward*v*3;
 public void Scatter(){if(!placed||!RoomDrive)return;foreach(var c in coins)if(c)Destroy(c.gameObject);coins.Clear();for(int i=0;i<30&&coins.Count<12;i++){var p=SpawnPoint(((i*.618034f+.13f)%1-.5f)*.9f,((i*.414214f+.27f)%1-.5f)*.9f);if(Vector3.Distance(p,car.position)>.3f)coins.Add(Part("Coin",PrimitiveType.Sphere,root,root.InverseTransformPoint(p+SurfaceNormal*.12f),new Vector3(.075f,.075f,.025f),gold).transform);}Notice("Coins spread around the car on the active surface.");}
 bool NearPlane(ARPlane plane,Vector3 world){var polygon=plane.boundary;if(!polygon.IsCreated||polygon.Length<3)return false;var p=plane.transform.InverseTransformPoint(world);var q=new Vector2(p.x,p.z);bool inside=false;float nearest=float.PositiveInfinity;for(int i=0,j=polygon.Length-1;i<polygon.Length;j=i++){var a=polygon[i];var b=polygon[j];if((a.y>q.y)!=(b.y>q.y)&&q.x<(b.x-a.x)*(q.y-a.y)/(b.y-a.y)+a.x)inside=!inside;var ab=b-a;float t=Mathf.Clamp01(Vector2.Dot(q-a,ab)/Mathf.Max(.00001f,ab.sqrMagnitude));nearest=Mathf.Min(nearest,Vector2.Distance(q,a+ab*t));}return inside||nearest<.1f;}
 bool TryJoin(Vector3 next){
  if(Practice||Mathf.Abs(speed)<.025f)return false;ARPlane best=null;Vector3 normal=Vector3.zero,point=Vector3.zero;float closest=float.PositiveInfinity;var travel=car.forward*Mathf.Sign(speed);
  foreach(var plane in planes.trackables){if(!plane||plane.subsumedBy||plane.trackingState!=TrackingState.Tracking||!SurfaceSelection.JunctionPatch(plane.size.x,plane.size.y))continue;var n=plane.transform.up;if(Vector3.Dot(n,car.position-plane.transform.position)<0)n=-n;float offset=Vector3.Dot(car.position-plane.transform.position,n);if(!SurfaceLinkRules.CanJoin(Vector3.Dot(SurfaceNormal,n),offset,Vector3.Dot(travel,n),Time.time-lastJoin))continue;var p=next-n*Vector3.Dot(next-plane.transform.position,n);if(!NearPlane(plane,p)||Vector3.Distance(car.position,p)>.3f)continue;if(Mathf.Abs(offset)<closest){closest=Mathf.Abs(offset);best=plane;normal=n;point=p;}}
  if(!best)return false;var f=Vector3.ProjectOnPlane(Quaternion.FromToRotation(SurfaceNormal,normal)*car.forward,normal).normalized;var entered=point+f*Mathf.Sign(speed)*.035f;if(!NearPlane(best,entered))entered=point;
  var previous=root;car.SetParent(null,true);root=new GameObject("Joined room surface").transform;root.SetPositionAndRotation(entered,Quaternion.LookRotation(f,normal));root.gameObject.AddComponent<ARAnchor>();car.SetParent(root,false);car.localPosition=Vector3.zero;car.localRotation=Quaternion.identity;foreach(var c in coins)if(c)Destroy(c.gameObject);coins.Clear();Destroy(previous.gameObject);manualSurface=false;surface=normal.y>.7f?"FLOOR":normal.y<-.7f?"CEILING":"WALL";revision++;joins++;lastJoin=Time.time;Scatter();Notice("Connected to "+surface+" / "+joins+" joins. Score continues.");return true;
 }
 Vector2 ScreenPointer()=>Touchscreen.current!=null&&(Touchscreen.current.primaryTouch.press.isPressed||Touchscreen.current.primaryTouch.press.wasPressedThisFrame)?Touchscreen.current.primaryTouch.position.ReadValue():Mouse.current!=null?Mouse.current.position.ReadValue():Vector2.zero;
 bool Pressed()=>(Mouse.current!=null&&Mouse.current.leftButton.wasPressedThisFrame)||(Touchscreen.current!=null&&Touchscreen.current.primaryTouch.press.wasPressedThisFrame);
 void ReadInput(){var input=controls?controls.Command:default;steer=input.Steering;throttle=input.Throttle;boost=input.Boost;brake=input.Braking;forceGo=input.ForceForward;if(Application.isEditor&&!Practice&&Mouse.current!=null&&Mouse.current.rightButton.isPressed){steer=throttle=0;boost=forceGo=false;return;}var k=Keyboard.current;if(k!=null){if(k.aKey.isPressed||k.leftArrowKey.isPressed)steer=-1;if(k.dKey.isPressed||k.rightArrowKey.isPressed)steer=1;if(k.wKey.isPressed||k.upArrowKey.isPressed)throttle=1;if(k.sKey.isPressed||k.downArrowKey.isPressed)throttle=-1;boost|=k.spaceKey.isPressed;if(k.rKey.wasPressedThisFrame)Recover();}if(boost&&throttle==0&&!brake)throttle=1;if(throttle<=0)forceGo=false;if(brake){throttle=0;boost=forceGo=false;}}
 void ClearDrive(){smoothSteer=0;if(controls)controls.Clear();speed=throttle=steer=0;boost=brake=forceGo=false;obstacleStop=false;}
 public void Recover(){if(!car)return;if(Flow&&Flow.Mode==RaceMode.Track){Flow.RecoverToGate();return;}ClearDrive();car.localPosition=Vector3.zero;car.localRotation=Quaternion.identity;Notice("Returned to the current surface's starting point.");}
 public void Replace(){if(Flow)Flow.Cleanup();ClearDrive();placementValid=selectedPreview=false;if(root)Destroy(root.gameObject);root=car=null;coins.Clear();placed=manual=manualSurface=scanMenu=scanning=false;activity.ResetUserPause();previewPlane=null;revision++;NewMarker();}
 public void CycleTarget(){if(placed){Notice("Reposition before changing placement target.");return;}selectedPreview=placementValid=false;choice=(choice+1)%4;if(placed&&!Practice)Replace();Notice(TargetLabel+". Tap the exact spot on the desired surface.");}
 public void ConfirmPlacement(){if(Flow.Stage==RaceStage.Placement&&PlacementAvailable)Place(new Pose(preview.position,Flow.Rotation(preview.rotation)));else Notice("Scan a textured surface slowly until the placement indicator appears.");}
 public void Halt(){ClearDrive();}
 public void ResumeRace(){activity.ResetUserPause();ClearDrive();}
 public void HideScan(){ShowScan=false;}
 public void ShowScanForPlacement(){ShowScan=true;}
 public void ResetRaceStats(){score=0;distance=elapsed=0;nitro=100;activity.ResetUserPause();ClearDrive();}
 public void CollectBoost(){nitro=Mathf.Min(100,nitro+35);score+=75;Flow.PickupFeedback();}
 public void SetObstacleBlocking(bool enabled){if(obstacles)obstacles.SetSensing(enabled);}
 public void ToggleObstacles(){if(obstacles)obstacles.SetSensing(!obstacles.SensingEnabled);Notice(SensorStatus);}
 public void IgnoreBlockingHit(){Notice(obstacles&&obstacles.IgnoreHit()?"NO BLOCK: 35cm around the last red contact. This spot stays in place.":"Drive toward the object first; NO BLOCK HIT needs a recent red contact.");}
 public void RestoreLastObstacle(){Notice(obstacles&&obstacles.RestoreLast()?"Last no-block spot restored.":"No ignored spots to restore.");}
 public void ClearIgnoredObstacles(){if(obstacles)obstacles.ClearIgnored();Notice("All no-block spots cleared.");}
 public void OpenScanMenu(){manual=false;scanMenu=true;ClearDrive();ShowScan=true;}
 public void CloseScanMenu(){scanMenu=scanning=false;ClearDrive();}
 public void BeginScanMore(){scanMenu=false;scanning=true;ClearDrive();ShowScan=true;Notice("Move slowly around corners and textured features, then DONE.");}
 public void ResetRoomMap(){Flow.Reposition();if(obstacles)obstacles.ClearIgnored();ShowScan=true;resetUntil=Time.unscaledTime+1.5f;if(!Practice)foreach(var s in FindObjectsByType<ARSession>())if(s.enabled)s.Reset();Notice("Map reset. Choose TARGET and tap the wanted surface.");}
 public void TogglePause(){activity.TogglePause();ClearDrive();}public void ToggleScan(){ShowScan=!ShowScan;}
 public void Award(int points){score+=points;nitro=Mathf.Min(100,nitro+20);Notice("Checkpoint +"+points);}
 public void BeginManualWall(){if(Practice){Notice("Manual wall calibration requires AR camera mode.");return;}Flow.Reposition();manual=true;scanMenu=scanning=false;}
 public void AdjustManualWall(float value){manualDistance=Mathf.Clamp(manualDistance+value,.35f,5);}
 public void CancelManualWall(){manual=false;if(marker)marker.gameObject.SetActive(false);}
 public void ConfirmManualWall(){if(manual&&!lost&&marker&&marker.gameObject.activeSelf)Place(new Pose(preview.position,Flow.Rotation(preview.rotation)));else Notice(TrackingAdvice);}
 void UpdateManual(){if(lost||scanMenu){marker.gameObject.SetActive(false);return;}var n=Vector3.ProjectOnPlane(-raceCamera.transform.forward,Vector3.up);if(n.sqrMagnitude<.1f){marker.gameObject.SetActive(false);return;}preview=new Pose(raceCamera.transform.position+raceCamera.transform.forward*manualDistance,Quaternion.LookRotation(Vector3.up,n.normalized));marker.SetPositionAndRotation(preview.position,preview.rotation);marker.gameObject.SetActive(true);}
 void Notice(string text){message=text;feedbackUntil=Time.time+3;}
 void OnApplicationPause(bool value){activity.SetApplicationPause(value);ClearDrive();}void OnApplicationFocus(bool value){activity.SetFocus(value);ClearDrive();}
}
}










