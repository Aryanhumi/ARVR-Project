using UnityEngine;
using UnityEngine.UI;
namespace ARRacing
{
    // Renders virtual content from a second camera. Never moves the tracked AR camera.
    public sealed class CarChaseView:MonoBehaviour
    {
        ARRaceGame game;Camera chase;RenderTexture texture;GameObject panel;
        public bool Selected {get;private set;}
        public void Initialize(ARRaceGame owner,RectTransform safeRoot){
            game=owner;
            var cameraObject=new GameObject("Optional chase camera");cameraObject.transform.SetParent(transform,false);chase=cameraObject.AddComponent<Camera>();
            chase.enabled=false;chase.clearFlags=CameraClearFlags.SolidColor;chase.backgroundColor=new Color(.025f,.045f,.07f);chase.nearClipPlane=.025f;chase.farClipPlane=40;chase.fieldOfView=58;
            texture=new RenderTexture(640,360,16){name="Chase preview",antiAliasing=1};texture.Create();chase.targetTexture=texture;
            var r=new GameObject("Third person window",typeof(RectTransform)).GetComponent<RectTransform>();r.SetParent(safeRoot,false);
            r.anchorMin=new Vector2(.25f,.32f);r.anchorMax=new Vector2(.75f,.77f);r.offsetMin=r.offsetMax=Vector2.zero;
            var content=new GameObject("Chase image",typeof(RectTransform),typeof(RawImage),typeof(AspectRatioFitter));content.transform.SetParent(r,false);
            var image=content.GetComponent<RawImage>();image.texture=texture;image.raycastTarget=false;
            var fitter=content.GetComponent<AspectRatioFitter>();fitter.aspectRatio=16f/9;fitter.aspectMode=AspectRatioFitter.AspectMode.FitInParent;
            panel=r.gameObject;panel.SetActive(false);
        }
        public void Toggle(){Selected=!Selected;}
        bool visibleLast;
        void LateUpdate(){
            bool visible=Selected&&game.HasCar&&game.Flow.Stage==RaceStage.Racing&&!game.ScanMenuOpen&&!game.ScanningMore&&!game.IsPaused;
            panel.SetActive(visible);chase.enabled=visible;
            if(!visible){visibleLast=false;return;}
            var car=game.PlayerCar;Vector3 up=game.SurfaceNormal,forward=Vector3.ProjectOnPlane(car.forward,up).normalized;if(forward.sqrMagnitude<.1f)forward=game.SurfaceForward;
            Vector3 surface=car.position-up*Vector3.Dot(car.position-game.SurfaceTransform.position,up);
            Vector3 target=surface-forward*.95f+up*.6f;
            float blend=visibleLast?1-Mathf.Exp(-8*Time.unscaledDeltaTime):1;
            chase.transform.position=Vector3.Lerp(chase.transform.position,target,blend);
            chase.transform.rotation=Quaternion.Slerp(chase.transform.rotation,Quaternion.LookRotation(surface+forward*.35f+up*.08f-chase.transform.position,up),blend);
            visibleLast=true;
        }
        void OnDisable(){if(chase)chase.enabled=false;if(panel)panel.SetActive(false);}
        void OnDestroy(){if(chase)Destroy(chase.gameObject);if(texture){texture.Release();Destroy(texture);}if(panel)Destroy(panel);}
    }
}

