using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using Unity.XR.CoreUtils;

namespace ARRacing
{
    // The saved scene needs only this component. All scene references are wired here.
    public class ARRaceBootstrap : MonoBehaviour
    {
        public static void ConfigureTracking(TrackedPoseDriver driver)
        {
            var position=new InputAction("AR Position",InputActionType.Value,expectedControlType:"Vector3");
            position.AddBinding("<HandheldARInputDevice>/devicePosition");
            position.AddBinding("<XRHMD>/centerEyePosition");
            var rotation=new InputAction("AR Rotation",InputActionType.Value,expectedControlType:"Quaternion");
            rotation.AddBinding("<HandheldARInputDevice>/deviceRotation");
            rotation.AddBinding("<XRHMD>/centerEyeRotation");
            var state=new InputAction("AR Tracking",InputActionType.Value,expectedControlType:"Integer");
            state.AddBinding("<HandheldARInputDevice>/trackingState");
            state.AddBinding("<XRHMD>/trackingState");
            driver.positionInput=new InputActionProperty(position);
            driver.rotationInput=new InputActionProperty(rotation);
            driver.trackingStateInput=new InputActionProperty(state);
        }
        void Awake()
        {
            bool useAR=!ARRaceGame.IsDesktop;
#if UNITY_EDITOR
            useAR=UnityEditor.EditorPrefs.GetBool("ARRacingSimulatedAR",false);
#endif
            var sessionObject=new GameObject("AR Session");
            sessionObject.SetActive(false);
            sessionObject.AddComponent<ARSession>().matchFrameRateRequested=true;sessionObject.AddComponent<ARInputManager>();
            sessionObject.SetActive(useAR);
            var root=new GameObject("XR Origin");root.SetActive(false);
            var origin=root.AddComponent<XROrigin>();
            origin.CameraYOffset=0;
            var offset=new GameObject("Camera Offset");offset.transform.SetParent(root.transform,false);origin.CameraFloorOffsetObject=offset;
            var cameraObject=new GameObject("AR Camera");cameraObject.tag="MainCamera";cameraObject.transform.SetParent(offset.transform,false);
            var camera=cameraObject.AddComponent<Camera>();camera.nearClipPlane=.01f;camera.farClipPlane=30;
            cameraObject.AddComponent<AudioListener>();var cameraManager=cameraObject.AddComponent<ARCameraManager>();cameraManager.autoFocusRequested=true;cameraManager.requestedBackgroundRenderingMode=CameraBackgroundRenderingMode.BeforeOpaques;cameraObject.AddComponent<ARCameraBackground>();
            var driver=cameraObject.AddComponent<TrackedPoseDriver>();
            ConfigureTracking(driver);
            driver.updateType=TrackedPoseDriver.UpdateType.UpdateAndBeforeRender;
            driver.trackingType=TrackedPoseDriver.TrackingType.RotationAndPosition;
            driver.enabled=useAR;
            origin.Camera=camera;
            var planes=root.AddComponent<ARPlaneManager>();planes.requestedDetectionMode=PlaneDetectionMode.Horizontal|PlaneDetectionMode.Vertical;
            var rays=root.AddComponent<ARRaycastManager>();root.AddComponent<ARAnchorManager>();root.SetActive(true);
            var light=new GameObject("Sun").AddComponent<Light>();light.type=LightType.Directional;light.intensity=1.2f;light.transform.rotation=Quaternion.Euler(50,-30,0);
            RenderSettings.ambientMode=UnityEngine.Rendering.AmbientMode.Flat;RenderSettings.ambientLight=new Color(.6f,.65f,.7f);
            var manager=new GameObject("Race Manager").AddComponent<ARRaceGame>();manager.planes=planes;manager.raycasts=rays;manager.raceCamera=camera;manager.practiceInEditor=!useAR;
#if UNITY_EDITOR
            manager.desktopSurfaceMode=UnityEditor.EditorPrefs.GetInt("ARRacingPracticeSurface",0);
#endif
        }
    }
}
