using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

namespace ARRacing
{
    public sealed class RaceTouchControls : MonoBehaviour
    {
        public ARRaceGame game;
        public readonly DriveInputState Input=new DriveInputState();
        readonly List<RaceHoldButton> holdButtons=new List<RaceHoldButton>();
        readonly List<RaceSwipePad> swipePads=new List<RaceSwipePad>();
        RectTransform safeRoot;GameObject modalShield;Button placementButton;Text startButtonLabel,placementTarget;HudScreen visibleScreen=HudScreen.None;bool initialized;
        GameObject controls,actions,scanPanel,manualPanel,mainPanel,placementPanel,readyPanel,resultsPanel;
        readonly List<Button> trackChoices=new List<Button>();
        Text modeTitle,trackType,sizeText,placeText,resultText,soundText,vibrationText,startInfo;Image boostFlash;
        Text roomLabel,manualDistanceLabel;

        Text scanTitle,scanDescription,scanMoreLabel;
        Text title,stats,status,feedback,hint,pauseLabel,scanLabel,floorLabel;
        Font font;CarChaseView chaseView;Text viewLabel;
        Rect previousSafe;
        int previousWidth,previousHeight;
        bool wasDriving;
        public DriveCommand Command=>Input.Read();

        public void Initialize(ARRaceGame owner)
        {
            if(initialized)return;game=owner;initialized=true;
            font=Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            var eventSystem=FindAnyObjectByType<EventSystem>();
            if(!eventSystem)
            {
                var events=new GameObject("Touch Event System",typeof(EventSystem));
                eventSystem=events.GetComponent<EventSystem>();
            }
            var uiInput=eventSystem.GetComponent<InputSystemUIInputModule>();
            if(!uiInput)
            {
                foreach(var oldModule in eventSystem.GetComponents<BaseInputModule>())oldModule.enabled=false;
                uiInput=eventSystem.gameObject.AddComponent<InputSystemUIInputModule>();uiInput.AssignDefaultActions();
            }
            foreach(var module in eventSystem.GetComponents<BaseInputModule>())if(module!=uiInput)module.enabled=false;
            uiInput.enabled=true;uiInput.pointerBehavior=UIPointerBehavior.AllPointersAsIs;
            var canvasObject=new GameObject("Touch HUD",typeof(RectTransform),typeof(Canvas),typeof(CanvasScaler),typeof(GraphicRaycaster));
            canvasObject.transform.SetParent(transform,false);
            var canvas=canvasObject.GetComponent<Canvas>();canvas.renderMode=RenderMode.ScreenSpaceOverlay;canvas.sortingOrder=100;
            var scaler=canvasObject.GetComponent<CanvasScaler>();scaler.uiScaleMode=CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution=new Vector2(1100,650);scaler.matchWidthOrHeight=.5f;
            safeRoot=new GameObject("Safe screen area",typeof(RectTransform)).GetComponent<RectTransform>();safeRoot.SetParent(canvasObject.transform,false);
            var header=Panel("Header",safeRoot,new Vector2(.01f,.87f),new Vector2(.99f,.99f),new Color(.025f,.045f,.08f,.94f));
            header.GetComponent<Image>().raycastTarget=true;
            title=Label("Title",header,"ROOM DRIVE",23,new Vector2(.02f,.62f),new Vector2(.98f,.97f));
            stats=Label("Stats",header,"",20,new Vector2(.02f,.3f),new Vector2(.98f,.63f));
            status=Label("Input status",header,"",18,new Vector2(.02f,.01f),new Vector2(.98f,.32f));
            actions=new GameObject("Actions",typeof(RectTransform));var actionRoot=actions.GetComponent<RectTransform>();actionRoot.SetParent(safeRoot,false);Stretch(actionRoot);
            viewLabel=Action(actionRoot,"VIEW: AR",new Vector2(.49f,.79f),new Vector2(.70f,.86f),()=>chaseView.Toggle());
            pauseLabel=Action(actionRoot,"PAUSE",new Vector2(.72f,.79f),new Vector2(.87f,.86f),()=>game.TogglePause());
            Action(safeRoot,"...",new Vector2(.88f,.795f),new Vector2(.99f,.865f),()=>{if(game.ScanMenuOpen)game.CloseScanMenu();else game.OpenScanMenu();});
            hint=Label("Car direction",safeRoot,"",20,new Vector2(.20f,.45f),new Vector2(.80f,.52f));hint.alignment=TextAnchor.MiddleCenter;
            feedback=Label("Feedback",safeRoot,"",20,new Vector2(.18f,.35f),new Vector2(.82f,.41f));feedback.alignment=TextAnchor.MiddleCenter;
            controls=new GameObject("Driving controls",typeof(RectTransform));var controlRoot=controls.GetComponent<RectTransform>();controlRoot.SetParent(safeRoot,false);Stretch(controlRoot);
            Swipe(controlRoot,false,new Vector2(.02f,.025f),new Vector2(.27f,.245f),new Color(.04f,.27f,.42f,.85f));
            Hold(controlRoot,"BRAKE",DriveControl.Brake,.33f,.47f,new Color(.48f,.08f,.12f,.85f),.025f,.16f);
            Hold(controlRoot,"BOOST",DriveControl.Nitro,.51f,.67f,new Color(.42f,.27f,.02f,.85f),.025f,.16f);
            Hold(controlRoot,"FORCE GO",DriveControl.ForceForward,.36f,.64f,new Color(.35f,.12f,.4f,.85f),.18f,.245f);
            Swipe(controlRoot,true,new Vector2(.74f,.025f),new Vector2(.99f,.245f),new Color(.02f,.32f,.23f,.85f));

            modalShield=Panel("Modal touch shield",safeRoot,Vector2.zero,Vector2.one,new Color(0,.015f,.03f,.32f)).gameObject;modalShield.GetComponent<Image>().raycastTarget=true;
            var menu=Panel("Three dot options",safeRoot,new Vector2(.06f,.14f),new Vector2(.94f,.79f),new Color(.025f,.045f,.085f,1));menu.GetComponent<Image>().raycastTarget=true;scanPanel=menu.gameObject;
            scanTitle=Label("Options title",menu,"OPTIONS / CAR PAUSED",25,new Vector2(.03f,.87f),new Vector2(.84f,.98f));
            scanDescription=Label("Details",menu,"",18,new Vector2(.03f,.76f),new Vector2(.96f,.87f));
            Action(menu,"CLOSE",new Vector2(.85f,.88f),new Vector2(.98f,.98f),()=>game.CloseScanMenu());
            roomLabel=MenuAction(menu,"BLOCKING",0,0,()=>game.ToggleObstacles());
            MenuAction(menu,"NO BLOCK HIT",1,0,()=>game.IgnoreBlockingHit());
            MenuAction(menu,"RESTORE HIT",2,0,()=>game.RestoreLastObstacle());
            MenuAction(menu,"CLEAR IGNORES",3,0,()=>game.ClearIgnoredObstacles());
            MenuAction(menu,"RECOVER",0,1,()=>{game.Recover();game.CloseScanMenu();});
            MenuAction(menu,"REPOSITION",1,1,()=>game.Flow.Reposition());
            scanMoreLabel=MenuAction(menu,"SCAN MORE",2,1,()=>{if(game.ScanningMore)game.CloseScanMenu();else game.BeginScanMore();});
            MenuAction(menu,"RESET MAP",3,1,()=>game.ResetRoomMap());
            soundText=MenuAction(menu,"SOUND OFF",0,2,()=>game.Flow.ToggleSound());
            vibrationText=MenuAction(menu,"VIBRATION OFF",1,2,()=>game.Flow.ToggleVibration());
            MenuAction(menu,"MANUAL WALL",2,2,()=>game.BeginManualWall());
            floorLabel=MenuAction(menu,"TARGET",3,2,()=>game.CycleTarget());
            MenuAction(menu,"FINISH RUN",0,3,()=>{game.CloseScanMenu();game.Flow.Finish();});
            MenuAction(menu,"MAIN MENU",1,3,()=>game.Flow.MainMenu());
            MenuAction(menu,"COINS",2,3,()=>game.Scatter());
            scanLabel=MenuAction(menu,"SCAN LINES",3,3,()=>game.ToggleScan());

            var main=Modal("Main menu",new Vector2(.18f,.28f),new Vector2(.82f,.76f));mainPanel=main.gameObject;
            Label("Welcome",main,"SURFACE RACER",36,new Vector2(.04f,.77f),new Vector2(.96f,.97f));
            Label("Choose mode",main,"Choose your drive. Scan, place, then start.",22,new Vector2(.04f,.59f),new Vector2(.96f,.77f));
            Action(main,"FREE DRIVE",new Vector2(.04f,.31f),new Vector2(.32f,.56f),()=>game.Flow.SelectMode(0));
            Action(main,"TRACK RACE",new Vector2(.36f,.31f),new Vector2(.64f,.56f),()=>game.Flow.SelectMode(1));
            Action(main,"OBSTACLE RUN",new Vector2(.68f,.31f),new Vector2(.96f,.56f),()=>game.Flow.SelectMode(2));
            Label("Mode descriptions",main,"Explore freely    /    3-10 laps + ghost    /    60-second score run",19,new Vector2(.04f,.07f),new Vector2(.96f,.28f));

            var placement=Modal("Placement",new Vector2(.05f,.025f),new Vector2(.95f,.40f));placementPanel=placement.gameObject;
            modeTitle=Label("Guide",placement,"",20,new Vector2(.02f,.88f),new Vector2(.98f,.98f));
            for(int i=0;i<3;i++){int type=i;var choice=Action(placement,new[]{"SPRINT GP","CHICANE GP","TECHNICAL GP"}[i],new Vector2(.02f+i*.325f,.66f),new Vector2(.325f+i*.325f,.84f),()=>game.Flow.SetTrack(type));trackChoices.Add(choice.transform.parent.GetComponent<Button>());}
            trackType=Action(placement,"LAPS",new Vector2(.02f,.37f),new Vector2(.27f,.61f),()=>game.Flow.CycleLaps());
            Action(placement,"SIZE -",new Vector2(.29f,.37f),new Vector2(.43f,.61f),()=>game.Flow.Resize(-.15f));
            sizeText=Label("Size",placement,"",21,new Vector2(.44f,.37f),new Vector2(.56f,.61f));
            Action(placement,"SIZE +",new Vector2(.57f,.37f),new Vector2(.71f,.61f),()=>game.Flow.Resize(.15f));
            Action(placement,"ROTATE",new Vector2(.73f,.37f),new Vector2(.98f,.61f),()=>game.Flow.RotatePreview());
            Action(placement,"BACK",new Vector2(.02f,.05f),new Vector2(.27f,.31f),()=>game.Flow.MainMenu());
            placementTarget=Action(placement,"TARGET",new Vector2(.29f,.05f),new Vector2(.56f,.31f),()=>game.CycleTarget());
            placeText=Action(placement,"PLACE TRACK",new Vector2(.58f,.05f),new Vector2(.98f,.31f),()=>game.ConfirmPlacement());

            placementButton=placeText.transform.parent.GetComponent<Button>();
            var ready=Modal("Start or resume",new Vector2(.28f,.34f),new Vector2(.72f,.67f));readyPanel=ready.gameObject;
            startInfo=Label("Ready details",ready,"",24,new Vector2(.05f,.56f),new Vector2(.95f,.95f));
            startButtonLabel=Action(ready,"START RACE",new Vector2(.05f,.10f),new Vector2(.95f,.48f),()=>{if(game.IsPaused)game.TogglePause();else game.Flow.StartRace();});

            var result=Modal("Results",new Vector2(.20f,.28f),new Vector2(.80f,.74f));resultsPanel=result.gameObject;
            resultText=Label("Result",result,"",29,new Vector2(.05f,.40f),new Vector2(.95f,.96f));
            Action(result,"RACE AGAIN",new Vector2(.05f,.10f),new Vector2(.48f,.32f),()=>game.Flow.RaceAgain());
            Action(result,"MAIN MENU",new Vector2(.52f,.10f),new Vector2(.95f,.32f),()=>game.Flow.MainMenu());

            var manual=Modal("Manual wall distance",new Vector2(.05f,.035f),new Vector2(.95f,.24f));manualPanel=manual.gameObject;
            manualDistanceLabel=Label("Manual distance",manual,"",20,new Vector2(.02f,.63f),new Vector2(.98f,.98f));
            Action(manual,"NEARER",new Vector2(.02f,.08f),new Vector2(.25f,.59f),()=>game.AdjustManualWall(-.1f));
            Action(manual,"FARTHER",new Vector2(.27f,.08f),new Vector2(.50f,.59f),()=>game.AdjustManualWall(.1f));
            Action(manual,"CONFIRM",new Vector2(.52f,.08f),new Vector2(.75f,.59f),()=>game.ConfirmManualWall());
            Action(manual,"CANCEL",new Vector2(.77f,.08f),new Vector2(.98f,.59f),()=>game.CancelManualWall());
            chaseView=gameObject.AddComponent<CarChaseView>();chaseView.Initialize(game,safeRoot);
            boostFlash=Panel("Boost flash",safeRoot,Vector2.zero,Vector2.one,Color.clear).GetComponent<Image>();boostFlash.raycastTarget=false;
            ApplySafeArea();ApplyScreen(HudScreen.Main);
        }
        void ApplyScreen(HudScreen screen)
        {
            bool changed=visibleScreen!=screen;visibleScreen=screen;
            if(changed)Clear();
            // Close every inactive screen before opening one; hidden screens cannot intercept touches.
            controls.SetActive(screen==HudScreen.Racing);
            actions.SetActive(screen==HudScreen.Racing);
            mainPanel.SetActive(screen==HudScreen.Main);
            placementPanel.SetActive(screen==HudScreen.Placement);
            readyPanel.SetActive(screen==HudScreen.Ready);
            resultsPanel.SetActive(screen==HudScreen.Results);
            scanPanel.SetActive(screen==HudScreen.Options);
            manualPanel.SetActive(screen==HudScreen.Manual);
            modalShield.SetActive(screen!=HudScreen.Racing&&screen!=HudScreen.None&&screen!=HudScreen.Placement);
        }
        void RefreshScreen()
        {
            if(!initialized||!game||!game.Flow)return;
            ApplyScreen(HudScreenRules.Resolve(game.Flow.Stage,game.ScanMenuOpen,game.ScanningMore,game.ManualWallCalibration,game.IsPaused,game.HasCar));
        }
        RectTransform Modal(string name,Vector2 min,Vector2 max){var p=Panel(name,safeRoot,min,max,new Color(.025f,.045f,.085f,1));p.GetComponent<Image>().raycastTarget=true;return p;}
        Text MenuAction(Transform parent,string caption,int column,int row,UnityEngine.Events.UnityAction action){float x=.025f+column*.245f,y=.58f-row*.18f;return Action(parent,caption,new Vector2(x,y),new Vector2(x+.23f,y+.16f),action);}
        void Stretch(RectTransform rect){rect.anchorMin=Vector2.zero;rect.anchorMax=Vector2.one;rect.offsetMin=rect.offsetMax=Vector2.zero;}
        RectTransform Panel(string name,Transform parent,Vector2 min,Vector2 max,Color color)
        {
            var g=new GameObject(name,typeof(RectTransform),typeof(Image));var r=g.GetComponent<RectTransform>();r.SetParent(parent,false);
            r.anchorMin=min;r.anchorMax=max;r.offsetMin=r.offsetMax=Vector2.zero;
            var image=g.GetComponent<Image>();image.color=color;image.raycastTarget=false;return r;
        }
        Text Label(string name,Transform parent,string value,int size,Vector2 min,Vector2 max)
        {
            var rect=new GameObject(name,typeof(RectTransform),typeof(Text)).GetComponent<RectTransform>();rect.SetParent(parent,false);
            rect.anchorMin=min;rect.anchorMax=max;rect.offsetMin=new Vector2(5,2);rect.offsetMax=new Vector2(-5,-2);
            var text=rect.GetComponent<Text>();text.font=font;text.text=value;text.fontSize=size;text.fontStyle=FontStyle.Bold;text.color=Color.white;
            text.alignment=TextAnchor.MiddleLeft;text.resizeTextForBestFit=true;text.resizeTextMinSize=12;text.resizeTextMaxSize=size;text.raycastTarget=false;return text;
        }
        Button Button(Transform parent,string text,Vector2 min,Vector2 max,Color color,out Text label)
        {
            var rect=Panel(text,parent,min,max,color);var image=rect.GetComponent<Image>();image.raycastTarget=true;
            var button=rect.gameObject.AddComponent<Button>();button.targetGraphic=image;button.navigation=new Navigation{mode=Navigation.Mode.None};
            var colors=button.colors;colors.normalColor=Color.white;colors.highlightedColor=new Color(.85f,.95f,1);colors.pressedColor=new Color(.25f,1,.65f);colors.disabledColor=new Color(.4f,.48f,.56f,1);colors.fadeDuration=.06f;button.colors=colors;
            var border=rect.gameObject.AddComponent<Outline>();border.effectColor=new Color(.25f,.7f,1,.55f);border.effectDistance=new Vector2(1,-1);border.useGraphicAlpha=true;
            label=Label("Label",rect,text,29,Vector2.zero,Vector2.one);label.alignment=TextAnchor.MiddleCenter;
            var press=rect.gameObject.AddComponent<RaceButtonFeedback>();press.caption=label;press.button=button;
            return button;
        }
        Text Action(Transform parent,string text,Vector2 min,Vector2 max,UnityEngine.Events.UnityAction action)
        {
            var button=Button(parent,text,min,max,new Color(.065f,.20f,.32f,1),out var label);
            button.onClick.AddListener(()=>{action();RefreshScreen();});label.resizeTextMaxSize=24;return label;
        }
        void Hold(Transform parent,string text,DriveControl control,float left,float right,Color color,float bottom=.025f,float top=.22f)
        {
            var button=Button(parent,text,new Vector2(left,bottom),new Vector2(right,top),color,out var label);
            var held=button.gameObject.AddComponent<RaceHoldButton>();held.owner=this;held.control=control;held.label=label;held.caption=text;held.image=button.GetComponent<Image>();held.normal=color;holdButtons.Add(held);
        }
        void Swipe(Transform parent,bool vertical,Vector2 min,Vector2 max,Color color)
        {
            string caption=vertical?"DRIVE":"STEER";
            var rect=Panel(vertical?"Forward reverse pad":"Steering pad",parent,min,max,color);
            var image=rect.GetComponent<Image>();image.raycastTarget=true;
            var pad=rect.gameObject.AddComponent<RaceSwipePad>();pad.owner=this;pad.vertical=vertical;pad.image=image;pad.normal=color;pad.caption=caption;
            pad.label=Label("Pad direction",rect,caption,20,vertical?new Vector2(.02f,.43f):new Vector2(.02f,.01f),vertical?new Vector2(.98f,.57f):new Vector2(.98f,.23f));pad.label.alignment=TextAnchor.MiddleCenter;swipePads.Add(pad);
            if(vertical){Arrow(rect,DriveControl.Forward,new Vector2(.32f,.59f),new Vector2(.68f,.96f),0);Arrow(rect,DriveControl.Reverse,new Vector2(.32f,.04f),new Vector2(.68f,.41f),180);}
            else{Arrow(rect,DriveControl.Left,new Vector2(.06f,.29f),new Vector2(.44f,.93f),90);Arrow(rect,DriveControl.Right,new Vector2(.56f,.29f),new Vector2(.94f,.93f),-90);}
        }
        void Arrow(Transform parent,DriveControl control,Vector2 min,Vector2 max,float rotation)
        {
            var rect=new GameObject(control+" arrow",typeof(RectTransform)).GetComponent<RectTransform>();rect.SetParent(parent,false);
            rect.anchorMin=min;rect.anchorMax=max;rect.offsetMin=rect.offsetMax=Vector2.zero;rect.localRotation=Quaternion.Euler(0,0,rotation);
            var arrow=rect.gameObject.AddComponent<RaceArrowIcon>();arrow.owner=this;arrow.control=control;arrow.raycastTarget=false;
        }
        public bool CanDrive=>initialized&&visibleScreen==HudScreen.Racing&&game&&game.IsDriving;
        public void Clear(){Input.Clear();foreach(var pad in swipePads)pad.ResetPointers();}
        void ApplySafeArea()
        {
            var safe=Screen.safeArea;if(Screen.width<=0||Screen.height<=0)return;
            safeRoot.anchorMin=new Vector2(safe.xMin/Screen.width,safe.yMin/Screen.height);
            safeRoot.anchorMax=new Vector2(safe.xMax/Screen.width,safe.yMax/Screen.height);safeRoot.offsetMin=safeRoot.offsetMax=Vector2.zero;
            previousSafe=safe;previousWidth=Screen.width;previousHeight=Screen.height;
        }
        void Update()
        {
            if(!initialized||!game)return;
            RefreshScreen();
            if(previousSafe!=Screen.safeArea||previousWidth!=Screen.width||previousHeight!=Screen.height)ApplySafeArea();
            if(wasDriving&&!CanDrive)Clear();wasDriving=CanDrive;
            var flow=game.Flow;if(!flow)return;
            bool menu=game.ScanMenuOpen||game.ScanningMore;


            viewLabel.text=chaseView.Selected?"VIEW: CHASE":"VIEW: AR";
            title.text="SURFACE RACER / "+flow.Mode;stats.text=flow.Stage==RaceStage.Placement?"SCAN > SELECT > PLACE":game.StatsText;
            status.text=flow.Stage==RaceStage.Racing?game.ControlStatus:game.TargetLabel+" / "+flow.TrackName;
            status.color=game.MovementBlocked?new Color(1,.73f,.25f):new Color(.5f,1,.8f);
            feedback.text=menu?"":game.FeedbackText;
            hint.text=visibleScreen==HudScreen.Racing&&!chaseView.Selected?game.CarHint:"";
            pauseLabel.text=game.IsPaused?"RESUME":"PAUSE";scanLabel.text=game.ShowScan?"HIDE LINES":"SHOW LINES";floorLabel.text=game.TargetLabel;
            scanDescription.text=game.ScanningMore?game.DetectedSurfaceCount+" surfaces. Move slowly, then DONE.":"No-block spots: "+game.IgnoredObstacleCount+" / Changes to placement require REPOSITION.";
            scanMoreLabel.text=game.ScanningMore?"DONE":"SCAN MORE";roomLabel.text=game.ObstaclesEnabled?"BLOCKING ON":"BLOCKING OFF";
            soundText.text=flow.Sound?"SOUND ON":"SOUND OFF";vibrationText.text=flow.Vibration?"VIBRATION ON":"VIBRATION OFF";


            modeTitle.text=game.PlacementAvailable?(flow.Mode==RaceMode.Track?flow.Footprint+" / tap to move; SIZE and ROTATE below.":"Preview ready: tap another spot or PLACE CAR."):"Scan slowly near corners or textured furniture. Waiting for a surface...";
            trackType.text=flow.Mode==RaceMode.Track?"LAPS: "+flow.RaceLaps:flow.Mode.ToString()+" DRIVE";
            for(int i=0;i<trackChoices.Count;i++){trackChoices[i].gameObject.SetActive(flow.Mode==RaceMode.Track);var colors=trackChoices[i].colors;colors.normalColor=i==flow.TrackType?new Color(.35f,1,.7f):Color.white;trackChoices[i].colors=colors;}
            sizeText.text=flow.Size.ToString("0.00")+"x";
            placeText.text=flow.Mode==RaceMode.Track?"PLACE TRACK":"PLACE CAR";placementButton.interactable=visibleScreen==HudScreen.Placement&&game.PlacementAvailable;
            placementTarget.text=game.TargetLabel;
            startButtonLabel.text=game.IsPaused?"RESUME RACE":"START RACE";

            startInfo.text=game.IsPaused?"PAUSED\nTrack and progress retained":flow.Mode==RaceMode.Track?"TRACK LOCKED\n"+flow.RaceLaps+" laps + ghost / "+flow.BestText:"READY\n"+flow.Mode;
            resultText.text=visibleScreen==HudScreen.Results?flow.ResultsText:"";
            manualDistanceLabel.text=visibleScreen==HudScreen.Manual?game.ManualWallText:"";
            boostFlash.color=new Color(.2f,1,.8f,flow.Flash/.22f*.15f);
            foreach(var button in holdButtons)button.GetComponent<Button>().interactable=CanDrive;
        }
        void LateUpdate(){RefreshScreen();}
        void OnApplicationFocus(bool focus){if(!focus)Clear();}
        void OnApplicationPause(bool pause){if(pause)Clear();}
        void OnDisable(){Clear();}
    }
    public sealed class RaceSwipePad:MonoBehaviour,IPointerDownHandler,IPointerUpHandler,IDragHandler,IInitializePotentialDragHandler
    {
        public RaceTouchControls owner;public bool vertical;public Image image;public Color normal;public Text label;public string caption;
        readonly Dictionary<int,Vector2> origins=new Dictionary<int,Vector2>();
        readonly Dictionary<int,DriveControl> active=new Dictionary<int,DriveControl>();
        public void OnInitializePotentialDrag(PointerEventData data){data.useDragThreshold=false;}
        bool Local(PointerEventData data,out Vector2 point)=>RectTransformUtility.ScreenPointToLocalPointInRectangle((RectTransform)transform,data.position,data.pressEventCamera,out point);
        public void OnPointerDown(PointerEventData data)
        {
            if(!owner.CanDrive||!Local(data,out var point))return;
            origins[data.pointerId]=point;var bounds=((RectTransform)transform).rect;
            var control=vertical?(point.y>=bounds.center.y?DriveControl.Forward:DriveControl.Reverse):(point.x>=bounds.center.x?DriveControl.Right:DriveControl.Left);
            active[data.pointerId]=control;owner.Input.Press(data.pointerId,control);
        }
        public void OnDrag(PointerEventData data)
        {
            if(!owner.CanDrive||!origins.TryGetValue(data.pointerId,out var origin)||!Local(data,out var point))return;
            var bounds=((RectTransform)transform).rect;
            float delta=vertical?(point.y-origin.y)/bounds.height:(point.x-origin.x)/bounds.width;
            var control=DriveSwipe.Resolve(vertical,delta,active[data.pointerId]);
            active[data.pointerId]=control;owner.Input.Press(data.pointerId,control);
        }
        public void OnPointerUp(PointerEventData data)
        {
            if(active.TryGetValue(data.pointerId,out var control))owner.Input.Release(data.pointerId,control);
            origins.Remove(data.pointerId);active.Remove(data.pointerId);
        }
        void OnDisable(){foreach(var entry in active)owner.Input.Release(entry.Key,entry.Value);ResetPointers();}
        public void ResetPointers(){origins.Clear();active.Clear();}
        void LateUpdate()
        {
            var command=owner.Command;float axis=vertical?command.Throttle:command.Steering;
            bool held=active.Count>0&&owner.CanDrive;
            image.color=!owner.CanDrive?normal*.6f:held?Color.Lerp(normal,Color.white,.35f):normal;
            label.text=held?(vertical?(axis>0?"FORWARD":axis<0?"REVERSE":"NEUTRAL"):(axis>0?"RIGHT":axis<0?"LEFT":"CENTRE")):caption;
        }
    }
    public sealed class RaceButtonFeedback:MonoBehaviour,IPointerDownHandler,IPointerUpHandler,IPointerExitHandler
    {
        public Text caption;public Button button;bool pressed;
        public void OnPointerDown(PointerEventData e){pressed=button.IsInteractable();}
        public void OnPointerUp(PointerEventData e){pressed=false;}
        public void OnPointerExit(PointerEventData e){pressed=false;}
        void OnDisable(){pressed=false;if(caption)caption.rectTransform.localScale=Vector3.one;}
        void LateUpdate(){if(!caption)return;caption.rectTransform.localScale=Vector3.one*(pressed?.94f:1);caption.color=button.IsInteractable()?(pressed?new Color(.65f,1,.85f):Color.white):new Color(.65f,.7f,.76f);}
    }
    public sealed class RaceArrowIcon:MaskableGraphic
    {
        public RaceTouchControls owner;public DriveControl control;
        protected override void OnPopulateMesh(VertexHelper helper)
        {
            helper.Clear();var rect=rectTransform.rect;float size=Mathf.Min(rect.width,rect.height);var centre=rect.center;
            var points=new[]{new Vector2(-.12f,-.36f),new Vector2(.12f,-.36f),new Vector2(.12f,.02f),new Vector2(-.12f,.02f),new Vector2(-.36f,-.02f),new Vector2(.36f,-.02f),new Vector2(0,.39f)};
            foreach(var p in points)helper.AddVert(centre+p*size,color,Vector2.zero);
            helper.AddTriangle(0,1,2);helper.AddTriangle(2,3,0);helper.AddTriangle(4,5,6);
        }
        void LateUpdate(){color=owner&&owner.CanDrive&&owner.Input.Held(control)?new Color(.2f,1,.7f):Color.white;}
    }
    public sealed class RaceHoldButton:MonoBehaviour,IPointerDownHandler,IPointerUpHandler,IPointerExitHandler
    {
        public RaceTouchControls owner;public DriveControl control;public Text label;public string caption;public Image image;public Color normal;
        public void OnPointerDown(PointerEventData data){if(owner.CanDrive)owner.Input.Press(data.pointerId,control);}
        public void OnPointerUp(PointerEventData data){owner.Input.Release(data.pointerId,control);}
        public void OnPointerExit(PointerEventData data){owner.Input.Release(data.pointerId,control);}
        void LateUpdate(){bool active=owner.Input.Held(control);image.color=active?Color.Lerp(normal,Color.white,.4f):normal;label.text=active?caption+"\nHELD":caption;}
    }
}









