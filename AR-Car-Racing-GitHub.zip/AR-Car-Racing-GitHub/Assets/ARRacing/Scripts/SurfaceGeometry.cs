using System;
namespace ARRacing
{
    public sealed class TrackingGate
    {
        float steady;
        public bool Ready=>steady>=.35f;
        public void Update(bool tracking,float seconds){steady=tracking?steady+Math.Max(0,Math.Min(.1f,seconds)):0;}
    }
    public static class SurfaceLinkRules
    {
        public static bool CanJoin(float normalDot,float distance,float approach,float sinceLastJoin)
            =>Math.Abs(normalDot)<.92f&&distance>=-.06f&&distance<=.18f&&approach<-.15f&&sinceLastJoin>.6f;
    }
    public static class SurfaceGeometry
    {
        public static bool Coplanar(float normalDot,float signedOffset)=>Math.Abs(normalDot)>.97f&&Math.Abs(signedOffset)<.12f;
        public static void Project(float x,float y,float z,float nx,float ny,float nz,out float px,out float py,out float pz)
        {float dot=x*nx+y*ny+z*nz;px=x-nx*dot;py=y-ny*dot;pz=z-nz*dot;}
    }
}
