using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
namespace ARRacing
{
    // Geometric depth probes only: does not classify chairs, slippers or people.
    public sealed class DepthObstacleSensor:MonoBehaviour
    {
        ARRaceGame game;AROcclusionManager occlusion;ARCameraManager cameraManager;
        Matrix4x4 display;bool hasDisplay,lastBlocked;float lastFrame=-10,lastCheck=-10,lastDirection,newDepthAt=-10;double lastImageStamp=-1;int blockedFrames;
        static readonly float[] sides={-.12f,-.06f,0,.06f,.12f},heights={.045f,.10f,.16f};
        public bool SensingEnabled {get;private set;}=true;
        Transform hitMarker;
        readonly ObstacleExclusions exclusions=new ObstacleExclusions();
        Vector3 lastContact;float lastContactAt=-100;
        public int IgnoredCount=>exclusions.Count;
        public bool IgnoreHit(){if(Time.unscaledTime-lastContactAt>8)return false;exclusions.Add(lastContact.x,lastContact.y,lastContact.z);lastContactAt=-100;ClearResult();lastCheck=-10;return true;}
        public bool RestoreLast(){bool restored=exclusions.Undo();ClearResult();lastCheck=-10;return restored;}
        public void ClearIgnored(){exclusions.Clear();lastContactAt=-100;ClearResult();lastCheck=-10;}
        string state="DEPTH: starting";
        public string Status=>!SensingEnabled?"OBSTACLES OFF":state;
        public void SetSensing(bool value){SensingEnabled=value;ClearResult();if(occlusion)occlusion.requestedEnvironmentDepthMode=value?EnvironmentDepthMode.Fastest:EnvironmentDepthMode.Disabled;state="DEPTH: warming up; move phone";}
        public void Initialize(ARRaceGame owner)
        {
            game=owner;if(game.DesktopDriving){state="DEPTH: phone only";return;}
            cameraManager=game.raceCamera.GetComponent<ARCameraManager>();cameraManager.frameReceived+=OnFrame;
            occlusion=game.raceCamera.GetComponent<AROcclusionManager>();if(!occlusion)occlusion=game.raceCamera.gameObject.AddComponent<AROcclusionManager>();
            occlusion.requestedEnvironmentDepthMode=EnvironmentDepthMode.Fastest;
            occlusion.environmentDepthTemporalSmoothingRequested=false;
            occlusion.requestedOcclusionPreferenceMode=OcclusionPreferenceMode.NoOcclusion;
            state="DEPTH: warming up; move phone";
        }
        void OnFrame(ARCameraFrameEventArgs frame){if(frame.displayMatrix.HasValue){display=frame.displayMatrix.Value;hasDisplay=true;lastFrame=Time.unscaledTime;}}
        public bool Blocked(Vector3 candidate,float direction)
        {
            if(!SensingEnabled||!occlusion||game.DesktopDriving){lastBlocked=false;blockedFrames=0;return false;}
            if(Time.unscaledTime-lastCheck<.04f&&direction==lastDirection)return lastBlocked;
            lastCheck=Time.unscaledTime;lastDirection=direction;
            if(!hasDisplay||Time.unscaledTime-lastFrame>.25f){state="DEPTH: waiting for current camera";return ClearResult();}
            if(!occlusion.TryAcquireEnvironmentDepthCpuImage(out var image))
            {
                state=occlusion.subsystem!=null&&occlusion.subsystem.subsystemDescriptor.environmentDepthImageSupported==Supported.Unsupported?"DEPTH UNSUPPORTED: no obstacle sensing":"DEPTH: no data; move phone slowly";
                return ClearResult();
            }
            try
            {
                if(image.timestamp!=lastImageStamp){lastImageStamp=image.timestamp;newDepthAt=Time.unscaledTime;}
                if(Time.unscaledTime-newDepthAt>.25f){state="DEPTH: stale data; scan again";return ClearResult();}
                if(image.format!=XRCpuImage.Format.DepthFloat32&&image.format!=XRCpuImage.Format.DepthUint16){state="DEPTH: unsupported image format";return ClearResult();}
                var plane=image.GetPlane(0);int valid=0,hits=0,inView=0;Vector3 contact=Vector3.zero;
                foreach(float side in sides)foreach(float height in heights)
                {
                    Vector3 probe=candidate+game.PlayerCar.forward*direction*.22f+game.PlayerCar.right*side+game.SurfaceNormal*height;
                    var viewport=game.raceCamera.WorldToViewportPoint(probe);if(viewport.z<=0||viewport.x<0||viewport.x>1||viewport.y<0||viewport.y>1)continue;inView++;
                    // Same row-vector display transform used by the installed ARCore background shader.
                    DepthCollisionRules.ImageUv(viewport.x,viewport.y,display.m00,display.m10,display.m01,display.m11,display.m20,display.m21,out float u,out float v);
                    if(u<0||u>1||v<0||v>1)continue;
                    int x=Mathf.Clamp((int)(u*image.width),0,image.width-1),y=Mathf.Clamp((int)(v*image.height),0,image.height-1);
                    int offset=y*plane.rowStride+x*plane.pixelStride;int bytes=image.format==XRCpuImage.Format.DepthFloat32?4:2;
                    if(offset<0||offset+bytes>plane.data.Length)continue;
                    float depth;
                    if(bytes==2)depth=(plane.data[offset]|plane.data[offset+1]<<8)*.001f;
                    else{int bits=plane.data[offset]|plane.data[offset+1]<<8|plane.data[offset+2]<<16|plane.data[offset+3]<<24;depth=System.BitConverter.Int32BitsToSingle(bits);}
                    if(!DepthCollisionRules.ValidDepth(depth))continue;valid++;
                    if(!DepthCollisionRules.NearbyDepth(viewport.z,depth))continue;
                    Vector3 obstacle=game.raceCamera.ViewportToWorldPoint(new Vector3(viewport.x,viewport.y,depth));
                    if(DepthCollisionRules.DrivingSurface(Vector3.Dot(obstacle-game.SurfaceTransform.position,game.SurfaceNormal))||exclusions.Contains(obstacle.x,obstacle.y,obstacle.z))continue;
                    Vector3 local=Quaternion.Inverse(game.PlayerCar.rotation)*(obstacle-candidate);
                    if(DepthCollisionRules.InsideCar(local.x,local.y,local.z)){hits++;contact+=obstacle;}
                }
                if(inView==0){state="DEPTH: car out of view";return ClearResult();}
                if(valid<2){state="DEPTH: low coverage";return ClearResult();}
                blockedFrames=hits>=2?blockedFrames+1:0;lastBlocked=blockedFrames>=2;
                if(lastBlocked){lastContact=contact/hits;lastContactAt=Time.unscaledTime;ShowContact(lastContact);}else if(hitMarker)hitMarker.gameObject.SetActive(false);
                state=lastBlocked?"DEPTH: obstacle ahead":"DEPTH ACTIVE (visible area only)";return lastBlocked;
            }
            finally{image.Dispose();}
        }
        void ShowContact(Vector3 point){if(!hitMarker){var g=GameObject.CreatePrimitive(PrimitiveType.Sphere);g.name="Depth obstacle contact";Destroy(g.GetComponent<Collider>());hitMarker=g.transform;hitMarker.SetParent(transform,false);hitMarker.localScale=Vector3.one*.05f;var template=Resources.Load<Material>("ARRacing/Scan");var material=template?new Material(template):new Material(Shader.Find("Universal Render Pipeline/Unlit"));material.color=new Color(1,.1f,.05f);g.GetComponent<Renderer>().sharedMaterial=material;}hitMarker.position=point;hitMarker.gameObject.SetActive(true);}
        bool ClearResult(){lastBlocked=false;blockedFrames=0;if(hitMarker)hitMarker.gameObject.SetActive(false);return false;}
        void Update(){if(game&&!game.IsDriving&&hitMarker)hitMarker.gameObject.SetActive(false);}
        void OnDisable(){if(cameraManager)cameraManager.frameReceived-=OnFrame;}
    }
}

