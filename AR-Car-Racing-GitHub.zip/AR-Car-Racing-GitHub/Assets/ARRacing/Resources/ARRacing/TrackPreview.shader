Shader "ARRacing/TransparentTrack"
{
 Properties { _BaseColor ("Color", Color) = (0.1,0.8,1,0.25) }
 SubShader {
 Tags { "RenderPipeline"="UniversalPipeline" "Queue"="Transparent" "RenderType"="Transparent" }
 Pass {
 Blend SrcAlpha OneMinusSrcAlpha
 ZWrite Off
 Cull Off
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 float4 _BaseColor;
 struct Attributes { float4 positionOS:POSITION; };
 struct Varyings { float4 positionCS:SV_POSITION; };
 Varyings vert(Attributes v){Varyings o;o.positionCS=TransformObjectToHClip(v.positionOS.xyz);return o;}
 half4 frag(Varyings i):SV_Target{return _BaseColor;}
 ENDHLSL
 }
 }
}
