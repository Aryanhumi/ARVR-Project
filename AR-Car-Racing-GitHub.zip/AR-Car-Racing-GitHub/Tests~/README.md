# Standalone logic checks

These are the existing development checks for input ownership, movement, surface geometry, obstacle filtering and circuit/ghost rules. They do not test native camera tracking, touch rendering or device performance.

From the repository root:

```powershell
powershell -ExecutionPolicy Bypass -File .\Tests~\Run-LogicChecks.ps1
```

If Unity is installed elsewhere, pass `-UnityEditor "D:/YourUnityEditor/Editor"`. The runner uses the SDK bundled with that editor and writes ignored results to `TestResults`.
