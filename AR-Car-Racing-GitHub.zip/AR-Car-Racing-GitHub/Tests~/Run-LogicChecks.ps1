param([string]$UnityEditor = 'C:/Program Files/Unity/Hub/Editor/6000.6.0f1/Editor')
$ErrorActionPreference = 'Stop'
$repo = Split-Path -Parent $PSScriptRoot
$sdk = Join-Path $UnityEditor 'Data/DotNetSdk'
$dotnet = Join-Path $sdk 'dotnet.exe'
$compiler = Get-ChildItem (Join-Path $sdk 'sdk') -Directory | Sort-Object Name -Descending | Select-Object -First 1
$refs = Get-ChildItem (Join-Path $sdk 'packs/Microsoft.NETCore.App.Ref') -Directory | Sort-Object Name -Descending | Select-Object -First 1
$refdir = Get-ChildItem (Join-Path $refs.FullName 'ref') -Directory | Sort-Object Name -Descending | Select-Object -First 1
$resultDir = Join-Path $repo 'TestResults'
New-Item -ItemType Directory -Force -Path $resultDir | Out-Null
$output = Join-Path $resultDir 'ControlsCheck.dll'
$lines = @(Get-ChildItem $refdir.FullName -Filter '*.dll' | ForEach-Object { '-r:"' + $_.FullName + '"' })
$lines += '-target:exe'
$lines += '-out:"' + $output + '"'
$lines += '"' + (Join-Path $PSScriptRoot 'ControlsCheck.cs') + '"'
foreach ($name in @('DriveInputState','SurfaceGeometry','RoomSensingRules','CircuitRules')) {
    $lines += '"' + (Join-Path $repo "Assets/ARRacing/Scripts/$name.cs") + '"'
}
$response = Join-Path $resultDir 'checks.rsp'
$lines | Set-Content -Encoding utf8 $response
& $dotnet (Join-Path $compiler.FullName 'Roslyn/bincore/csc.dll') "@$response"
if ($LASTEXITCODE -ne 0) { throw 'Logic-check compilation failed.' }
'{"runtimeOptions":{"tfm":"net8.0","framework":{"name":"Microsoft.NETCore.App","version":"8.0.0"},"rollForward":"LatestMajor"}}' | Set-Content -Encoding utf8 (Join-Path $resultDir 'ControlsCheck.runtimeconfig.json')
& $dotnet $output
if ($LASTEXITCODE -ne 0) { throw 'Logic checks failed.' }
