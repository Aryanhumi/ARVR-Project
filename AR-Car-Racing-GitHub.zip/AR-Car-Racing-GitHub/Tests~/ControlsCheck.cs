using System;
using ARRacing;
static class ControlsCheck {
 static int passed;
 static void Check(bool result,string name){if(!result)throw new Exception(name);Console.WriteLine("PASS "+name);passed++;}
 static bool Near(float a,float b)=>Math.Abs(a-b)<.0001f;
 static float Run(float speed,float throttle,bool boost,bool brake,int frames){for(int i=0;i<frames;i++)speed=DriveMotion.Step(speed,throttle,boost,brake,1f/60);return speed;}
 static void Main(){
  var input=new DriveInputState();
  Check(input.Read().Throttle==0&&input.Read().Steering==0,"Idle does not accelerate");
  input.Press(1,DriveControl.Forward);input.Press(2,DriveControl.Left);
  Check(input.Read().Throttle==1&&input.Read().Steering==-1,"Two fingers steer and accelerate simultaneously");
  input.Release(2,DriveControl.Left);
  Check(input.Read().Throttle==1&&input.Read().Steering==0,"Releasing steering keeps accelerator held");
  input.Release(99,DriveControl.Forward);
  Check(input.Read().Throttle==1,"Unrelated finger cannot release accelerator");
  input.Press(3,DriveControl.Forward);input.Release(1,DriveControl.Forward);
  Check(input.Read().Throttle==1,"Second finger on the same button remains active");
  input.Press(4,DriveControl.Nitro);Check(input.Read().Boost,"Nitro works with accelerator");
  input.Press(5,DriveControl.Brake);Check(input.Read().Braking&&input.Read().Throttle==0&&!input.Read().Boost,"Brake overrides acceleration and nitro");
  input.Clear();Check(input.Read().Throttle==0&&!input.Read().Braking&&!input.Read().Boost,"Pause or focus loss clears every held control");
  input.Press(1,DriveControl.Left);input.Press(1,DriveControl.Right);input.Release(1,DriveControl.Left);
  Check(input.Read().Steering==1,"Old button exit cannot cancel the same finger's new button");
  input.Press(2,DriveControl.Left);Check(input.Read().Steering==0,"Opposite steering inputs cancel");
  input.Clear();input.Press(1,DriveControl.Reverse);Check(input.Read().Throttle==-1,"Reverse has its own input");
  input.Press(2,DriveControl.Forward);Check(input.Read().Throttle==0,"Opposite pedals cancel");
  Check(Near(Run(0,1,false,false,120),.8f),"GO accelerates to normal speed");
  Check(Near(Run(0,-1,false,false,120),-.45f),"Reverse moves backward");
  Check(Near(Run(0,1,true,false,120),1.3f),"Nitro increases forward speed");
  Check(Near(Run(.8f,1,true,true,30),0),"Brake stops a moving car without reversing");
  Check(Near(Run(.8f,0,false,false,120),0),"Releasing GO coasts to a stop");
  Check(Near(DriveMotion.Step(0,1,false,false,0),0),"Zero elapsed time does not move");
  Check(Near(DriveMotion.Step(0,1,false,false,1),DriveMotion.Step(0,1,false,false,.05f)),"Frame spikes clamp acceleration");
  input.Clear();input.Press(10,DriveControl.Nitro);
  Check(input.Read().Throttle==1&&input.Read().Boost,"Boost independently accelerates forward");
  input.Press(11,DriveControl.Left);
  Check(input.Read().Throttle==1&&input.Read().Steering==-1&&input.Read().Boost,"Steering and standalone boost work together");
  input.Press(12,DriveControl.Brake);
  Check(input.Read().Throttle==0&&!input.Read().Boost,"Brake overrides standalone boost");
  input.Clear();input.Press(10,DriveControl.Nitro);input.Press(11,DriveControl.Reverse);
  Check(input.Read().Throttle==-1&&!input.Read().Boost,"Explicit reverse overrides standalone boost");
  input.Clear();input.Press(10,DriveControl.Nitro);input.Release(10,DriveControl.Nitro);
  Check(input.Read().Throttle==0&&!input.Read().Boost,"Releasing standalone boost clears forward input");
  Check(DriveSwipe.Resolve(false,.2f,DriveControl.Left)==DriveControl.Right,"Rightward swipe selects right");
  Check(DriveSwipe.Resolve(false,-.2f,DriveControl.Right)==DriveControl.Left,"Leftward swipe selects left");
  Check(DriveSwipe.Resolve(true,.2f,DriveControl.Reverse)==DriveControl.Forward,"Upward swipe selects forward");
  Check(DriveSwipe.Resolve(true,-.2f,DriveControl.Forward)==DriveControl.Reverse,"Downward swipe selects reverse");
  Check(DriveSwipe.Resolve(true,.02f,DriveControl.Reverse)==DriveControl.Reverse,"Small finger jitter does not switch direction");
  input.Clear();input.Press(20,DriveSwipe.Resolve(false,-.2f,DriveControl.Right));input.Press(21,DriveSwipe.Resolve(true,.2f,DriveControl.Reverse));
  Check(input.Read().Throttle==1&&input.Read().Steering==-1,"Both swipe pads operate simultaneously");
  input.Release(21,DriveControl.Forward);
  Check(input.Read().Throttle==0&&input.Read().Steering==-1,"Lifting throttle finger preserves steering finger");
  var activity=new DriveSessionState();Check(activity.CanDrive,"Session starts ready without a USB flag");
  activity.SetApplicationPause(true);activity.SetFocus(false);Check(!activity.CanDrive,"Android interruption stops movement");
  activity.SetApplicationPause(false);Check(!activity.CanDrive,"Pause callback alone cannot bypass lost focus");
  activity.SetFocus(true);Check(activity.CanDrive,"Returning to foreground resumes without a sticky manual pause");
  activity.TogglePause();activity.SetApplicationPause(true);activity.SetApplicationPause(false);activity.SetFocus(false);activity.SetFocus(true);
  Check(!activity.CanDrive&&activity.UserPaused,"An intentional manual pause survives Android interruptions");
  activity.TogglePause();Check(activity.CanDrive,"Manual Resume restores driving");
  Check(SurfaceGeometry.Coplanar(1,0),"Mapped floor accepts a coplanar floor");
  Check(SurfaceGeometry.Coplanar(-1,0),"Ceiling or flipped plane normals remain coplanar");
  Check(SurfaceGeometry.Coplanar(.999f,.025f),"Small AR normal and anchor drift are tolerated");
  Check(!SurfaceGeometry.Coplanar(0,0),"An intersecting wall does not become part of the floor");
  Check(!SurfaceGeometry.Coplanar(1,.2f),"A separate parallel surface is rejected");
  Check(!SurfaceGeometry.Coplanar(.95f,0),"An angled neighboring surface is rejected");
  SurfaceGeometry.Project(1,2,3,0,1,0,out float floorX,out float floorY,out float floorZ);
  Check(Near(floorX,1)&&Near(floorY,0)&&Near(floorZ,3),"Floor driving stays in its tangent plane");
  SurfaceGeometry.Project(1,2,3,0,-1,0,out float ceilingX,out float ceilingY,out float ceilingZ);
  Check(Near(ceilingX,1)&&Near(ceilingY,0)&&Near(ceilingZ,3),"Ceiling driving stays against the ceiling");
  SurfaceGeometry.Project(1,2,3,0,0,-1,out float wallX,out float wallY,out float wallZ);
  Check(Near(wallX,1)&&Near(wallY,2)&&Near(wallZ,0),"Wall driving preserves horizontal and vertical wall travel");
  SurfaceGeometry.Project(1,2,3,1,0,0,out float sideX,out float sideY,out float sideZ);
  Check(Near(sideX,0)&&Near(sideY,2)&&Near(sideZ,3),"Side-wall driving stays on the side wall");
  float diagonal=(float)(1/Math.Sqrt(2));
  SurfaceGeometry.Project(1,2,3,diagonal,diagonal,0,out float dx,out float dy,out float dz);
  Check(Near(dx*diagonal+dy*diagonal,0)&&Near(dz,3),"Projection also supports an inclined detected plane");
  var tracking=new TrackingGate();tracking.Update(true,.1f);tracking.Update(true,.1f);tracking.Update(true,.1f);
  Check(!tracking.Ready,"Driving waits for a brief stable tracking period");
  tracking.Update(true,.1f);Check(tracking.Ready,"Steady tracking enables driving");
  tracking.Update(false,.01f);Check(!tracking.Ready,"Tracking loss immediately closes the driving gate");
  tracking.Update(true,.1f);Check(!tracking.Ready,"A single recovered frame cannot resume driving");
  Check(SurfaceLinkRules.CanJoin(0,.08f,-1,1),"A nearby approached perpendicular surface can be joined");
  Check(!SurfaceLinkRules.CanJoin(1,.08f,-1,1),"Coplanar surfaces cannot cause a corner turn");
  Check(!SurfaceLinkRules.CanJoin(-1,.08f,-1,1),"Opposite parallel surfaces cannot flip the car");
  Check(!SurfaceLinkRules.CanJoin(0,.4f,-1,1),"Distant ceilings or walls cannot teleport the car");
  Check(!SurfaceLinkRules.CanJoin(0,.08f,1,1),"Moving away from a surface cannot trigger a join");
  Check(!SurfaceLinkRules.CanJoin(0,.08f,-1,.3f),"Join cooldown prevents immediate corner oscillation");
  Check(!SurfaceLinkRules.CanJoin(0,-.1f,-1,1),"A surface too far behind the car is rejected");
  Check(SurfaceLinkRules.CanJoin(0,-.025f,-1,1),"Small crossing overshoot can still connect");
  Check(SurfaceSelection.Accept(0,0)&&SurfaceSelection.Accept(0,1)&&SurfaceSelection.Accept(0,-1),"Auto selection accepts all plane orientations");
  Check(SurfaceSelection.Accept(1,1)&&!SurfaceSelection.Accept(1,0)&&!SurfaceSelection.Accept(1,-1),"Floor filter excludes walls and ceilings");
  Check(SurfaceSelection.Accept(2,0)&&!SurfaceSelection.Accept(2,1),"Wall filter excludes floor hits");
  Check(SurfaceSelection.Accept(3,-1)&&!SurfaceSelection.Accept(3,1),"Ceiling filter excludes floor hits");
  Check(!SurfaceSelection.JunctionPatch(.1f,2)&&SurfaceSelection.JunctionPatch(.8f,1),"Corner routing rejects thin furniture-sized plane fragments");
  Check(!DepthCollisionRules.ValidDepth(0)&&!DepthCollisionRules.ValidDepth(float.NaN)&&!DepthCollisionRules.ValidDepth(float.PositiveInfinity),"Missing or invalid depth does not become a collision");
  Check(DepthCollisionRules.ValidDepth(1.2f)&&!DepthCollisionRules.ValidDepth(10),"Depth validity uses the intended sensing range");
  Check(DepthCollisionRules.InsideCar(.05f,.1f,.20f),"A depth point in the car footprint can be an obstacle");
  Check(!DepthCollisionRules.InsideCar(0,0,.1f),"The driving floor is excluded from obstacles");
  Check(!DepthCollisionRules.InsideCar(.4f,.1f,.1f),"Objects to the side do not block the car");
  Check(!DepthCollisionRules.InsideCar(0,.8f,.1f),"Geometry above car height is not a body collision");
  Check(!DepthCollisionRules.NearbyDepth(3,1),"A distant foreground occluder is not a nearby car collision");
  Check(DepthCollisionRules.NearbyDepth(2,1.9f),"Nearby measured depth is eligible for geometric checking");
  DepthCollisionRules.ImageUv(.2f,.3f,1,0,0,1,0,0,out float uvx,out float uvy);
  Check(Near(uvx,.2f)&&Near(uvy,.3f),"Identity display transform preserves coordinates");
  DepthCollisionRules.ImageUv(.2f,.3f,1,0,0,-1,0,1,out uvx,out uvy);
  Check(Near(uvx,.2f)&&Near(uvy,.7f),"CPU image vertical-flip coordinates are handled");
  DepthCollisionRules.ImageUv(.2f,.3f,0,1,-1,0,0,1,out uvx,out uvy);
  Check(Near(uvx,.3f)&&Near(uvy,.8f),"Row-major rotated display coordinates are handled");
  var escape=new DriveInputState();
  escape.Press(1,DriveControl.ForceForward);
  Check(escape.Read().Throttle==1&&escape.Read().ForceForward&&!escape.Read().Boost,"force drives without boost");
  escape.Press(2,DriveControl.Left);
  Check(escape.Read().Steering==-1&&escape.Read().ForceForward,"force allows simultaneous steering");
  escape.Press(3,DriveControl.Brake);
  Check(escape.Read().Throttle==0&&!escape.Read().ForceForward,"brake overrides force");
  escape.Release(3,DriveControl.Brake);escape.Press(4,DriveControl.Reverse);
  Check(escape.Read().Throttle==-1&&!escape.Read().ForceForward,"reverse overrides force");
  escape.Release(4,DriveControl.Reverse);escape.Release(1,DriveControl.ForceForward);
  Check(!escape.Read().ForceForward&&escape.Read().Throttle==0,"force ends on release");
  escape.Press(1,DriveControl.ForceForward);escape.Clear();
  Check(!escape.Read().ForceForward,"lifecycle clear ends force");
  Check(DepthCollisionRules.DrivingSurface(0)&&DepthCollisionRules.DrivingSurface(-.05f)&&DepthCollisionRules.DrivingSurface(.05f),"active plane tolerance both sides");
  Check(!DepthCollisionRules.DrivingSurface(.08f),"raised object remains eligible");
  var zones=new ObstacleExclusions();
  Check(!zones.Contains(0,0,0)&&!zones.Undo(),"empty exclusions");
  zones.Add(1,2,3);
  Check(zones.Contains(1.2f,2,3)&&!zones.Contains(1.5f,2,3),"ignore spot bounded radius");
  Check(!zones.Contains(1,2.5f,3),"ignore radius is three dimensional");
  zones.Add(5,2,3);
  Check(zones.Undo()&&zones.Count==1&&!zones.Contains(5,2,3)&&zones.Contains(1,2,3),"restore last preserves other spot");
  zones.Clear();Check(zones.Count==0&&!zones.Contains(1,2,3),"map reset clears spots");
  for(int i=0;i<20;i++)zones.Add(i,0,0,.1f);
  Check(zones.Count==16&&!zones.Contains(0,0,0)&&zones.Contains(19,0,0),"bounded exclusion count drops oldest");
  var circuit=new CircuitProgress();
  Check(circuit.Next==1&&circuit.Laps==0&&!circuit.Finished,"circuit starts before first ordered gate");
  Check(!circuit.Visit(0,8)&&!circuit.Visit(3,8),"start line and skipped gates do not count");
  for(int lap=0;lap<3;lap++){for(int gate=1;gate<8;gate++)Check(circuit.Visit(gate,8),"ordered circuit gate");Check(circuit.Visit(0,8)&&circuit.Laps==lap+1,"full lap counted only after ordered gates");}
  Check(circuit.Finished&&!circuit.Visit(1,8),"third lap finishes once");
  circuit.Reset();Check(!circuit.Finished&&circuit.Next==1&&circuit.Laps==0,"race again resets progress");
  Check(CircuitShape.Size(.1f)==.75f&&CircuitShape.Size(9)==4,"track resize bounds");
  for(int kind=0;kind<3;kind++){CircuitShape.Point(kind,0,out float ax,out float az);CircuitShape.Point(kind,1,out float bx,out float bz);Check(Near(ax,bx)&&Near(az,bz),"circuit loop closes");}
  Check(CircuitShape.SmoothAxis(0,1,0)==0&&CircuitShape.SmoothAxis(0,1,.05f)>0&&CircuitShape.SmoothAxis(0,1,.05f)<1,"steering eases without snapping");
  Check(Near(CircuitShape.SmoothAxis(0,1,10),CircuitShape.SmoothAxis(0,1,.05f)),"steering clamps frame spikes");
  float launch=DriveMotion.Step(0,1,false,false,1f/60);
  float later=DriveMotion.Step(.7f,1,false,false,1f/60)-.7f;
  Check(launch>later&&later>0,"acceleration eases as speed approaches target");
  Check(HudScreenRules.Resolve(RaceStage.Menu,false,false,false,false,false)==HudScreen.Main,"startup shows only main menu");
  Check(HudScreenRules.Resolve(RaceStage.Placement,false,false,false,false,false)==HudScreen.Placement,"placement hides results and manual panels");
  Check(HudScreenRules.Resolve(RaceStage.Ready,false,false,false,false,true)==HudScreen.Ready,"placed car shows start screen only");
  Check(HudScreenRules.Resolve(RaceStage.Racing,false,false,false,false,true)==HudScreen.Racing,"race shows driving controls only");
  Check(HudScreenRules.Resolve(RaceStage.Racing,false,false,false,true,true)==HudScreen.Ready,"pause switches to resume screen");
  Check(HudScreenRules.Resolve(RaceStage.Results,false,false,false,false,true)==HudScreen.Results,"finish shows results only");
  foreach(RaceStage stage in Enum.GetValues(typeof(RaceStage))){
   Check(HudScreenRules.Resolve(stage,true,false,false,false,true)==HudScreen.Options,"options supersedes stage panel");
   Check(HudScreenRules.Resolve(stage,false,true,false,false,true)==HudScreen.Options,"scan menu supersedes stage panel");
   Check(HudScreenRules.Resolve(stage,false,false,true,false,false)==HudScreen.Manual,"manual calibration supersedes stage panel");
  }
  Check(HudScreenRules.Resolve(RaceStage.Racing,false,false,false,false,false)==HudScreen.None,"missing car cannot expose drive controls");
  Check(HudScreenRules.Resolve(RaceStage.Placement,false,false,false,false,false)==HudScreen.Placement,"cancel manual returns to placement");
  Check(HudScreenRules.Resolve(RaceStage.Menu,false,false,false,true,true)==HudScreen.Main,"stale pause cannot overlay main menu");
  foreach(int laps in new[]{3,5,10}){var gp=new CircuitProgress();gp.Configure(laps);for(int lap=0;lap<laps;lap++){for(int gate=1;gate<16;gate++)gp.Visit(gate,16);gp.Visit(0,16);}Check(gp.Finished&&gp.Laps==laps,"selectable GP distance finishes at chosen lap");}
  Check(!CircuitShape.OffRoad(.8f,.3f,.1f)&&CircuitShape.OffRoad(.8f,.3f,.21f),"off-road grace filters brief edge jitter");
  Check(!CircuitShape.OffRoad(.35f,.3f,1),"road edge tolerance avoids false crashes");
  Check(Near(CircuitShape.SegmentDistance(1,1,0,0,2,0),1)&&Near(CircuitShape.SegmentDistance(-1,0,0,0,2,0),1),"road collision uses segments including endpoints");
  for(int kind=0;kind<3;kind++){
    var pace=new CircuitPace(kind,1);var large=new CircuitPace(kind,2);
    Check(pace.Length>12&&Near(large.Length,pace.Length*2),"larger GP increases actual racing distance");
    Check(Near(pace.Parameter(0),0)&&Near(pace.Parameter(pace.Length),0),"ghost wraps exactly at finish");
    for(int n=1;n<10;n++){float metres=pace.Length*n/10f;Check(Math.Abs(pace.DistanceAt(pace.Parameter(metres))-metres)<.002f,"ghost maintains metre-based pace through corners");}
    // Nonadjacent centre-line segments must not cross.
    bool crosses=false;for(int a=0;a<160;a++)for(int b=a+2;b<160;b++){if(a==0&&b==159)continue;CircuitShape.Point(kind,a/160f,out float ax,out float az);CircuitShape.Point(kind,(a+1)/160f,out float bx,out float bz);CircuitShape.Point(kind,b/160f,out float cx,out float cz);CircuitShape.Point(kind,(b+1)/160f,out float endX,out float endZ);float c1=(bx-ax)*(cz-az)-(bz-az)*(cx-ax),c2=(bx-ax)*(endZ-az)-(bz-az)*(endX-ax),c3=(endX-cx)*(az-cz)-(endZ-cz)*(ax-cx),c4=(endX-cx)*(bz-cz)-(endZ-cz)*(bx-cx);if(c1*c2<0&&c3*c4<0)crosses=true;}
    Check(!crosses,"GP layout has no crossing centre-line");
  }
  Console.WriteLine(passed+" checks passed");
 }
}












